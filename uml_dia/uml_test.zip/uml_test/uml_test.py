##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import osv, fields

class school_cal(osv.osv):
	"""Calendar"""
	_name = 'school.cal'
	_columns = {
		'name': fields.char('Name', size=32, help='Name of the event'),
	}
school_cal()

class school_event(osv.osv):
	"""Calendar"""
	_name = 'school.event'
	_columns = {
		'name': fields.char('Name', size=32, help='Name of the event'),
	}
school_event()

class school_course(osv.osv):
	"""Courses defined for the current school jkljkjdkd dsk dkljkl jqs q """
	_name = 'school.course'
	_columns = {
		'name': fields.char('Course', size=32, help='This is the name of the course'),
		'prof_id': fields.many2one('res.partner','Professor', help='The professor'),
	}
school_course()

class courses_student(osv.osv):
	"""(NULL)"""
	_name = 'courses.student'
	_columns = {
	}
courses_student()

class res_partner(osv.osv):
	"""(NULL)"""
	_name = 'res.partner'
	_columns = {
	}
res_partner()

