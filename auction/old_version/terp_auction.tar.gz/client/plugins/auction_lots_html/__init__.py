import service

def auction_lots_html(datas):
	pass

