import common
import re

import workflow_print
import slideshow
import huissier
import auction_lots_html

plugins_repository = {
	'workflow_print': {'model':'.*', 'string':'Print Workflow', 'action': workflow_print.wkf_print },
	'workflow_print_simple': {'model':'.*', 'string':'Print Workflow Simple', 'action': workflow_print.wkf_print_simple },
	'auction_lots_html': {'model':'auction.lots', 'string':'HTML Catalog', 'action': auction_lots_html.auction_lots_html },
	'slideshow': {'model':'.*', 'string':'Slideshow', 'action': slideshow.slideshow_start },
	'huissier': {'model':'.*', 'string':'Vente multi-form', 'action': huissier.huissier_start }
}

def execute(datas):
	result = {}
	for p in plugins_repository:
		if not 'model_re' in plugins_repository[p]:
			plugins_repository[p]['model_re'] = re.compile(plugins_repository[p]['model'])
		res = plugins_repository[p]['model_re'].search(datas['model'])
		if res:
			result[plugins_repository[p]['string']] = p
	if not len(result):
		common.message(_('No available plugin for this resource !'))
		return False
	sel = common.selection(_('Choose a Plugin'), result, allwaysask=True)
	if sel:
		plugins_repository[sel[1]]['action'](datas)
	return True

