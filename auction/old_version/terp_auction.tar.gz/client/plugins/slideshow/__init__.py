##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
from gtk import glade
import gobject

import rpc
import common
import gettext
import base64
import gc

_delay = 8000

class slideshow(object):
	def __init__(self, did):
		self.xml = glade.XML(common.terp_path("terp.glade"), "dia_slideshow", gettext.textdomain())
		self.win = self.xml.get_widget('dia_slideshow')
		self.did = did
		ids = rpc.session.rpc_exec_auth('/object', 'execute', 'auction.lots', 'search', [('auction_id','=',did)])
		self.lots = rpc.session.rpc_exec_auth('/object', 'execute', 'auction.lots', 'read', ids)
		self.pos = 0
		self.detail_pos = 0
		self.ids = None
		self.datas = None
		self.xml.signal_connect('on_eb_button_press_event', self.sig_clicked)

		self.entry = self.xml.get_widget('slide_entry')
		self.entry.connect('activate', self._entry_activate)
		self.next_callback = None
		self.old_scaled_buf = None
		self._reload()

	def _reload(self):
		datas = self.lots[self.pos]
		w1 = self.xml.get_widget('slide_entry')
		w1.set_text(str(self.lots[self.pos]['obj_num']))
		
		w2 = self.xml.get_widget('slide_tv')
		buffer = w2.get_buffer()
		buffer.delete(buffer.get_start_iter(), buffer.get_end_iter())
		iter_start = buffer.get_start_iter()
		buffer.insert(iter_start, self.lots[self.pos]['obj_desc'])
		self.detail_pos=0
		if self.next_callback:
			gobject.source_remove(self.next_callback)
			self.next_callback = None
		self.preview(True)

	def _entry_activate(self, *args):
		try:
			num = int(self.entry.get_text())
			ids = rpc.session.rpc_exec_auth('/object', 'execute', 'auction.lots', 'search', [('auction_id','=',self.did),('obj_num','=',num)])
			id = ids[0]
			pos = 0
			while pos<len(self.lots):
				if self.lots[pos]['id']==id:
					self.pos = pos
					break
				pos += 1
			self._reload()
		except:
			pass

	def sig_clicked(self, widget, event):
		if event.button==1:
			if self.pos<len(self.lots)-1:
				self.pos+=1
			else:
				self.pos = 0
		elif event.button==3:
			if self.pos>0:
				self.pos-=1
			else:
				self.pos=len(self.lots)-1
		self._reload()

	def preview(self, reload=False):
		id = self.lots[self.pos]['id']
		if reload or (not self.ids):
			self.ids = rpc.session.rpc_exec_auth('/object', 'execute', 'ir.attachment', 'search', [('res_model','=','auction.lots'), ('res_id', '=',id)])
			self.datas = rpc.session.rpc_exec_auth('/object', 'execute', 'ir.attachment', 'read', self.ids)

		if not len(self.datas):
			img = self.xml.get_widget('slide_image')
			img.set_from_stock(gtk.STOCK_DIALOG_WARNING,gtk.ICON_SIZE_DIALOG)
			return None

		datas = self.datas[self.detail_pos % len(self.datas)]
		self.detail_pos += 1
		fname = str(datas['datas_fname'])

		decoder = {'jpg':'jpg','jpeg':'jpeg'}
		ext = fname.split('.')[-1].lower()
		if ext in ('jpg','jpeg', 'png'):
			def Image_to_GdkPixbuf (contents):
				loader = gtk.gdk.PixbufLoader ()
				loader.write (contents, len (contents))
				pixbuf = loader.get_pixbuf ()
				loader.close ()
				del loader
				return pixbuf

			pixbuf = Image_to_GdkPixbuf(base64.decodestring(datas['datas']))
			dest = (750, 410)
			w = pixbuf.get_width()
			h = pixbuf.get_height()
			if (float(w)/h) > (float(dest[0])/dest[1]):
				dest2 =  (dest[0], h*dest[0]/w)
			else:
				dest2 =  (w*dest[1]/h, dest[1])
			scaled_buf = pixbuf.scale_simple(dest2[0],dest2[1],gtk.gdk.INTERP_BILINEAR)
			img = self.xml.get_widget('slide_image')
			img.set_from_pixbuf(scaled_buf)
			if self.old_scaled_buf:
				del self.old_scaled_buf
			self.old_scaled_buf = scaled_buf
			del pixbuf
			gc.collect()
		self.next_callback = gobject.timeout_add(_delay, self.preview)

	def start(self):
		self.win.run()
		if self.next_callback:
			gobject.source_remove(self.next_callback)
			self.next_callback = None
		self.win.destroy()
		if self.old_scaled_buf:
			del self.old_scaled_buf

def slideshow_start(datas):
	dates = dict([(x[1],x[0]) for x in rpc.session.rpc_exec_auth('/object', 'execute', 'auction.dates', 'name_search', '',[])])
	res = common.selection(_('Select a date'), dates)
	s = slideshow(res[1])
	s.start()

