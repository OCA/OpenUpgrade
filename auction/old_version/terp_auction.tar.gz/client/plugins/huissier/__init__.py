##############################################################################
#
# Copyright (c) 2005 TINY SPRL. (http://tiny.be) All Rights Reserved.
#
# $Id$
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
from gtk import glade
import gobject
import widget

import rpc
import common
import gettext
import base64
import gc

_delay = 8000

class huissier(object):
	def __init__(self, did):
		self.xml = glade.XML(common.terp_path("terp.glade"), "dia_huissier", gettext.textdomain())
		self.win = self.xml.get_widget('dia_huissier')
		self.vbox = self.xml.get_widget('huissier_sbox')
		self.next_callback = False
		self.did = did
		view = rpc.session.rpc_exec_auth('/object', 'execute', 'huissier.lots', 'fields_view_get', 0, 'form', rpc.session.context)
		self.forms = []
		for i in range(15):
			res = widget.form(view['arch'], view['fields'], 'auction.lots', parent=self.win, window=self.win)
			self.forms.append(res)
			self.vbox.pack_start(res.widget)
		self.vbox.show_all()

	def start(self):
		self.win.run()
		if self.next_callback:
			gobject.source_remove(self.next_callback)
			self.next_callback = None
		self.win.destroy()
		if self.old_scaled_buf:
			del self.old_scaled_buf
	
def huissier_start(datas):
	dates = dict([(x[1],x[0]) for x in rpc.session.rpc_exec_auth('/object', 'execute', 'auction.dates', 'name_search', '',[])])
	res = common.selection(_('Select a date'), dates)
	s = huissier(res and res[1])
	s.start()

