##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
from gtk import glade
import gobject
import gettext

from view_tree import parse
import widget.search
import rpc

fields_list_type = {
	'checkbox': gobject.TYPE_BOOLEAN,
	'integer': gobject.TYPE_INT,
	'float': gobject.TYPE_FLOAT
}

class win_list(object):
	def __init__(self, model, sel_multi=True, context={}):
		self.sel_multi = sel_multi
		self.context = context
		self.context.update(rpc.session.context)

		self.view = gtk.TreeView()
		self.view.set_reorderable(True)
		if not sel_multi:
			self.view.get_selection().set_mode('single')
		else:
			self.view.get_selection().set_mode(gtk.SELECTION_MULTIPLE)

		self.model_name = model
		view = rpc.session.rpc_exec_auth('/object', 'execute', model, 'fields_view_get', False, 'tree', rpc.session.context)
		self.view_data = view

		p = parse.parse(view['fields'])
		p.parse(view['arch'], self.view)

		self.view.set_expander_column(self.view.get_column(1))
		self.view.set_headers_visible(True)
		self.fields_order = p.fields_order

		types=[ gobject.TYPE_STRING ]
		for x in self.fields_order:
			types.append( fields_list_type.get(view['fields'][x]['type'], gobject.TYPE_STRING))

		self.view.get_column(0).set_visible(False)
		for i in range(len(types)):
			col = self.view.get_column(i)
			col.set_sort_column_id(i)
			col.set_reorderable(True)
			col.set_clickable(True)

		self.view_name = view['name']
		self.model = gtk.ListStore(*types)

		self.view.set_model(self.model)
		self.view.show_all()

		self.widget = self.view

	def reload(self, ids):
		self.model.clear()
#		print 'CONTEXT', self.context
		res = rpc.session.rpc_exec_auth('/object', 'execute', self.model_name, 'read', ids, self.fields_order, self.context)
#		print "res", res
		for field in self.fields_order:
			if self.view_data['fields'][field]['type'] in ('one2one','many2one'):
				for r in res:
					if r[field]:
						r[field] = r[field][1]
			elif self.view_data['fields'][field]['type'] == 'one2many':
#			elif self.view_data['fields'][field]['type'] in ('one2many', 'many2many'):
				# only take the first one
				ids = [r[field][0] for r in res if r[field]]
				values = rpc.session.rpc_exec_auth('/object', 'execute', self.view_data['fields'][field]['relation'], 'name_get', ids)
				dict_values = dict(values)
#				print "dict", dict_values
				for i in range(len(res)):
					if res[i][field]:
						res[i][field] = dict_values[res[i][field][0]]
						
		for r in res:
			num = self.model.append()
			self.model.set(num, 0, r['id'])
			for x in range(len(self.fields_order)):
				if r[self.fields_order[x]]:
					self.model.set(num, x+1, r[self.fields_order[x]])

	def _func_sel_get(self, *args):
		args[3].append(int(args[0].get_value(args[2], 0)))

	def sel_pos_set(self, num):
		sel = self.view.get_selection()
		sel.unselect_all()
		sel.select_path((num,))
		
	def sel_pos_get(self):
		sel = self.view.get_selection()
		model,iter = sel.get_selected()
		if not iter:
			return None
		return model.get_path(iter)[0]

	def sel_ids_get(self):
		sel = self.view.get_selection()
		ids = []
		sel.selected_foreach(self._func_sel_get, ids)
		return ids
