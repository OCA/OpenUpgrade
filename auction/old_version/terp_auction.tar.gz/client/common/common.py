##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
from gtk import glade
import gobject

import gettext

import os
import common
import logging
import options

def _search_file(x):
	if os.path.isfile(x):
		return x
	else:
		return os.path.join(os.path.join(os.path.dirname(__file__),'..',x))

terp_path = _search_file
terp_path_pixmaps = _search_file


def start_file(fname):
	try:
		if os.name == 'nt':
			os.startfile(fname)
		else:
			os.spawnv(os.P_NOWAIT, '/usr/bin/launcher',  ('launcher',fname))
	except Exception, e:
		common.error('Execution Error', _('Unable to launch this file !'), str(e))

def start_content(content, fname=None):
	try:
		if not fname:
			fname='terp.tmp'
		ext = fname.split('.')[-1]

		import tempfile
		fp_name = tempfile.mktemp ("."+ext)

		fp = file(fp_name, 'wb')
		fp.write(content)
		fp.close()
	except:
		common.message(_('Unable to launch the application associated to this content !'))
		
	start_file(fp_name)

#
# TODO: this code sucks
#
def selection(title, values, allwaysask=False):
	if len(values)==0:
		return None
	elif len(values)==1 and (not allwaysask):
		key = values.keys()[0]
		return (key, values[key])
	xml = glade.XML(terp_path("terp.glade"), "win_selection", gettext.textdomain())
	win = xml.get_widget('win_selection')
	label = xml.get_widget('win_sel_title')
	if title:
		label.set_text(title)
	list = xml.get_widget('win_sel_tree')
	list.get_selection().set_mode('single')
	cell = gtk.CellRendererText()
	column = gtk.TreeViewColumn("Widget", cell, text=0)
	list.append_column(column)
	list.set_search_column(0)
	model = gtk.ListStore(gobject.TYPE_STRING)
	keys = values.keys()
	keys.sort()
	for val in keys:
		num = model.append()
		model.set(num, 0, val)
	list.set_model(model)
	list.connect('row-activated', lambda x,y,z: win.response(gtk.RESPONSE_OK) or True)

	ok = False
	while not ok:
		response = win.run()
		ok = True
		res = None
		if response == gtk.RESPONSE_OK:
			sel = list.get_selection().get_selected()
			if sel:
				(model, iter) = sel 
				if iter:
					res = model.get_value(iter, 0)
					res = (res, values[res])
				else:
					ok = False
			else:
				ok = False
		else:
			res = None
	win.destroy()
	return res

def tipoftheday():
	class tip(object):
		def __init__(self):
			try:
				self.number = int(options.options['tip.position'])
			except:
				self.number = 0
				log = logging.getLogger('common.message')
				log.error('Invalid value for option tip.position ! See ~/.terprc !')
				print options.options['tip.position']
			winglade=glade.XML(common.terp_path("terp.glade"), "win_tips", gettext.textdomain())
			self.win = winglade.get_widget('win_tips')
			self.label = winglade.get_widget('tip_label')
			self.check = winglade.get_widget('tip_checkbutton')
			dict = {
				'on_but_next_activate': self.tip_next,
				'on_but_previous_activate': self.tip_previous,
				'on_but_close_activate': self.tip_close,
			}
			for signal in dict:
				winglade.signal_connect(signal, dict[signal])
			self.tip_set()
			self.win.show_all()

		def tip_set(self):
			tips = file('tipoftheday.txt').read().split('---')
			tip = tips[self.number % len(tips)]
			del tips
			self.label.set_text(tip)
			self.label.set_use_markup( True )

		def tip_next(self, *args):
			self.number+=1
			self.tip_set()

		def tip_previous(self, *args):
			if self.number>0:
				self.number -= 1
			self.tip_set()

		def tip_close(self, *args):
			check = self.check.get_active()
			options.options['tip.autostart'] = check
			options.options['tip.position'] = self.number+1
			options.options.save()
			self.win.destroy()

	tip2 = tip()
	return True

def test():
	gl = glade.XML(terp_path("terp.glade"), "dialog_test",gettext.textdomain())
	widget = gl.get_widget('dialog_test')
	widget.run()
	widget.destroy()
	return True

def file_selection(title, ext='csv'):
	win = gtk.FileSelection(title)
	win.set_filename(os.path.join(options.options['client.default_path'],'.'))
	win.set_select_multiple(False)
	button = win.run()
	if button!=gtk.RESPONSE_OK:
		win.destroy()
		return False
	res = win.get_selections()
	if res[0]:
		try:
			options.options['client.default_path'] = os.path.dirname(res[0])
		except:
			pass
	win.destroy()
	return res[0]

def error(title, message, details=''):
	log = logging.getLogger('common.message')
	log.error('MSG %s: %s' % (str(message),details))

	sur = glade.XML(terp_path("terp.glade"), "win_error",gettext.textdomain())
	win = sur.get_widget('win_error')
	sur.get_widget('error_title').set_text(str(title))
	sur.get_widget('error_info').set_text(str(message))
	buf = gtk.TextBuffer()
	buf.set_text(unicode(details,'latin1').encode('utf-8'))
	sur.get_widget('error_details').set_buffer(buf)
	win.run()
	win.destroy()

def message(msg, type=gtk.MESSAGE_INFO):
	dialog = gtk.MessageDialog(None,
	  gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
	  type, gtk.BUTTONS_OK,
	  msg)
	dialog.run()
	dialog.destroy()

def to_xml(s):
	return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def warning(msg, title='', parent=None):
	log = logging.getLogger('common.message')
	log.warning('MSG %s: %s' % (str(title),msg))
	
	dialog = gtk.MessageDialog(parent, gtk.DIALOG_DESTROY_WITH_PARENT, gtk.MESSAGE_WARNING, gtk.BUTTONS_OK)
	dialog.set_markup('<b>%s</b>\n\n%s' % (to_xml(title),to_xml(msg)))
	dialog.show_all()
	dialog.run()
	dialog.destroy()

def sur(msg):
	sur = glade.XML(terp_path("terp.glade"), "win_sur",gettext.textdomain())
	win = sur.get_widget('win_sur')
	l = sur.get_widget('lab_question')
	l.set_text(msg)
	response = win.run()
	win.destroy()
	return response == gtk.RESPONSE_OK

def dec_trunc(nbr, prec=2):
	return round(nbr * (10 ** prec)) / 10**prec
