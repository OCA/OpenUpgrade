##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
from gtk import glade

import wid_int
import rpc
import os

import common

class wid_binary(wid_int.wid_int):
	def __init__(self, parent, attrs={}):
		wid_int.wid_int.__init__(self, parent, attrs)
		self.win_gl = glade.XML(common.terp_path("terp.glade"),"widget_binary")
		self.win_gl.signal_connect('on_but_new_clicked', self.sig_new)
		self.win_gl.signal_connect('on_but_open_clicked', self.sig_open)
		self.win_gl.signal_connect('on_but_remove_clicked', self.sig_remove)
		self.win_gl.signal_connect('on_but_save_as_clicked', self.sig_save_as)
		self.widget = self.win_gl.get_widget('widget_binary')

		self.wid_text = self.win_gl.get_widget('ent_binary')
		self.value=False

	def sig_new(self, widget=None):
		try:
			filename = common.file_selection(_('Select the file to attach'))
			self.value = file(filename).read()
			fname = self.attrs.get('fname_widget', False)
			if fname:
				self.parent.value = {fname:os.path.basename(filename)}
		except:
			common.message(_('Error reading the file'))

	def sig_save_as(self, widget=None):
		try:
			filename = common.file_selection(_('Save attachment as...'))
			fp = file(filename,'wb+')
			fp.write(self._value)
			fp.close()
		except:
			common.message(_('Error writing the file!'))

	def sig_open(self, widget=None):
		fname = self.attrs.get('fname_widget', False)
		common.start_content(self._value, fname)

	def sig_remove(self, widget=None):
		self.value = False
		fname = self.attrs.get('fname_widget', False)
		if fname:
			self.parent.value = {fname:False}

	def _value_get(self):
		return self._value

	def _size_get(self, l):
		return str(l)+' octets'

	def _value_set(self, value):
		self._value = value
		if self._value:
			self.wid_text.set_text( _('Attachement: ')+ self._size_get(len(value)) )
		else:
			self.wid_text.set_text( '/' )

	value = property(_value_get, _value_set, None,
	  'The content of the widget or ValueError if not valid')
