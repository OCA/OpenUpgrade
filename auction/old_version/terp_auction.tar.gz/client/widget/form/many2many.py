##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gobject
import gtk
from gtk import glade

import wid_int
import wid_common
import common

class many2many(wid_int.wid_int):
	def __init__(self, parent, attrs={}):
		wid_int.wid_int.__init__(self, parent, attrs)

		self.win_gl = glade.XML(common.terp_path("terp.glade"),"widget_many2many")
		self.win_gl.signal_connect('on_m2m_but_add_pressed', self._sig_add )
		self.win_gl.signal_connect('on_m2m_but_remove_pressed', self._sig_remove )
		self.win_gl.signal_connect('on_m2m_but_refresh_pressed', self._sig_refresh )

		self.widget = self.win_gl.get_widget('widget_many2many')
		self.treeview = self.win_gl.get_widget('m2m_treeview')
		col = gtk.TreeViewColumn('ID', gtk.CellRendererText(), text=0)
		self.treeview.append_column(col)
		col = gtk.TreeViewColumn('Name', gtk.CellRendererText(), text=1)
		self.treeview.append_column(col)


		self.model = gtk.ListStore(gobject.TYPE_UINT, gobject.TYPE_STRING)
		self.treeview.set_model(self.model)

		self.model_type = attrs['relation']

		self.wid_text = self.win_gl.get_widget('ent_many2many')
		self.wid_text.connect('activate', self._sig_activate)
		self.wid_text.connect('button_press_event', self._menu_open)
		self._value=[]

	def _menu_sig_pref(self, obj):
		self._menu_sig_default_set()

	def _menu_sig_default(self, obj):
		res = rpc.session.rpc_exec_auth('/object', 'execute', self.attrs['model'], 'default_get', [self.attrs['name']])
		self.value = res.get(self.attrs['name'], False)

	def _list_reload(self):
		self.model.clear()
		for data in self._value:
			id = self.model.append()
			self.model.set(id, 0, int(data[0]))
			self.model.set(id, 1, data[1])

	def _sig_add(self, *args):
		arg = self._domain_get(self.parent)
		arg2 = self._context_get(self.parent)
		vals = self.trigger('many2one_sel', (self.parent.model, self.name, self.wid_text.get_text(), self.model_type, arg, arg2, True))
		if vals:
			for val in vals:
				self._value.append( (int(val[0]),val[1]) )
				if self.attrs.get('on_change',False):
					self.on_change(self.attrs['on_change'])
		self.wid_text.set_text('')
		self._list_reload()

	def _sig_remove(self, *args):
		selection = self.treeview.get_selection()
		result = selection.get_selected()
		if result:
			model, iter = result
			if iter:
				id = int(model.get_value(iter, 0))
				self._value = filter(lambda x: x[0]<>id, self._value)
				self._list_reload()
				if self.attrs.get('on_change',False):
					self.on_change(self.attrs['on_change'])

	def _sig_refresh(self, *args):
		self._list_reload()

	def _sig_activate(self, *args):
		self._sig_add()

	def _value_set(self, value):
		if value:
			self._value = self.trigger('names_get', (self.model_type, value))
		else:
			self._value = []
		self._list_reload()

	def _value_get(self):
		return [ x[0] for x in self._value ]

	def clear(self):
		self._value = []
		self._list_reload()
		return []

	value = property(_value_get, _value_set, None,
	  'The content of the widget or ValueError if not valid')

