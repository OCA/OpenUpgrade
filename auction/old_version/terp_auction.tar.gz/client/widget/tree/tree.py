##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import gtk
import gobject
from xml.parsers import expat

import rpc
import gettext
import parse

class tree(object):
	def __init__(self, xml, fields, model=None, triggers=[], parent=None, state="draft"):
		self.widget = gtk.TreeView()
		self.widget.set_reorderable(True)
		self.widget.get_selection().set_mode('single')
		self.model = model
		self.fields = fields
		self.sort_col = False
		self.ids = {}

		p = parse.parse(self.fields)
		p.parse(xml, self.widget)
		self.name = p.title
		self.fields_order=p.fields_order
		self.colors=p.colors

		self.widget.set_expander_column(self.widget.get_column(1))
		self.widget.set_headers_visible(True)

		types=[ gobject.TYPE_STRING ]
		for x in self.fields_order:
			types.append( fields_list_type.get(fields[x]['type'], gobject.TYPE_STRING))
		self.model = gtk.ListStore(*types)
		self.widget.set_model(self.model)

		self.widget.get_column(0).set_visible(False)
		for i in range(len(types)):
			col = self.widget.get_column(i)
			col.set_sort_column_id(i)
			col.set_reorderable(True)
			col.set_clickable(True)
		self.widget.show_all()

	def sel_id_get(self):
		return self.ids.get(self.pos_get(), False)

	def pos_get(self):
		sel = self.widget.get_selection().get_selected()
		if sel:
			model, iter = sel
			if not iter:
				return None
			id = model.get_value(iter,0)
			return int(id)
		return None

	def _value_get(self):
		return []

	def _value_set(self, val):
		self.model.clear()
		i = 0

		tochange = {}
		if len(val):
			for f in val[0].keys():
				if self.fields.has_key(f):
					if self.fields[f]['type'] in ('many2one','one2one'):
						try:
							ids = [v[f] for v in val if type(v[f])==type(1)]
							if len(ids):
								values = dict(rpc.session.rpc_exec_auth('/object', 'execute', self.fields[f]['relation'], 'name_get', ids))
								tochange[f] = values
						except:
							pass
					elif self.fields[f]['type'] in ('one2many'):
						ids = [v[f][0] for v in val if len(v[f])>0]
						if len(ids):
							values = dict(rpc.session.rpc_exec_auth('/object', 'execute', self.fields[f]['relation'], 'name_get', ids))
							tochange[f] = values[0]

		for data in val:
			id = self.model.append()
			self.model.set(id, 0, i)
			self.ids[i] = data.get('id', False)
			for f in range(len(self.fields_order)):
				f2 = self.fields_order[f]
				if data.get(f2, False):
					if self.fields[f2]['type'] in ('many2one','one2one', 'one2many'):
						if type(data[f2])==type(1):
							self.model.set(id, f+1, tochange[f2].get(data[f2],''))
						else:
							self.model.set(id, f+1, data[f2][1])
					else:
						self.model.set(id, f+1, data[f2])
#			row = self.model[i]
#			if i%%2:
#				row.set_attribute
			i+=1

	value = property(_value_get, _value_set, None,
	  'The content of the widget or ValueError if not valid')



fields_list_type = {
	'checkbox': gobject.TYPE_BOOLEAN,
	'integer': gobject.TYPE_INT,
	'float': gobject.TYPE_FLOAT
}


