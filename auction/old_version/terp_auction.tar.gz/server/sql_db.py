##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import psycopg
import tools
import sys,os


class fake_cursor:
	def __init__(self,db,con):
		self.db=db
		self.obj=db.cursor()
		self.con=con
#	def execute(self,*args):
#		print ' sql:', args
#		return self.obj.execute(*args)
	def close(self):
#		print "b4 close cursors fno:",[i.fileno() for i in self.db.cursors]
		self.obj.close()
		del self.obj
#		print "after close cursors fno:",[i.fileno() for i in self.db.cursors]
	def __getattr__(self, name):
#		print 'LOOK',name
		return getattr(self.obj,name)

class fakedb:
	def __init__(self,truedb):
		self.truedb=truedb
	def cursor(self):
		return fake_cursor(self.truedb,{})

def init():
	global db
	host = tools.config['db_host'] and "host=%s" % tools.config['db_host'] or ''
	port = tools.config['db_port'] and "port=%s" % tools.config['db_port'] or ''
	name = "dbname=%s" % tools.config['db_name']
	user = tools.config['db_user'] and "user=%s" % tools.config['db_user'] or ''
	password = tools.config['db_password'] and "password=%s" % tools.config['db_password'] or ''
	tdb = psycopg.connect('%s %s %s %s %s' % (host, port, name, user, password), serialize=0)
	db = fakedb(tdb)
	#define DATEOID 1082, define TIMESTAMPOID 1114 see pgtypes.h
	psycopg.register_type(psycopg.new_type((1082,), "date", lambda x:x))
	psycopg.register_type(psycopg.new_type((1114,), "datetime", lambda x:x))

