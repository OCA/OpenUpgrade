##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#
# $Id: custom.py 969 2005-07-18 12:04:46Z ged $
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import os, time
import netsvc

import tools
import print_xml
import render
from interface import report_int
import common

class report_custom(report_int):
	def __init__(self, name):
		report_int.__init__(self, name)
	def create(self, uid, ids, datas,context={}):
		service = netsvc.LocalService("object_proxy")
		report_id = datas['report_id']
		service = netsvc.LocalService("object_proxy")
		report = service.execute(uid, 'ir.report.custom', 'read', [report_id], context=context)[0]
		fields = service.execute(uid, 'ir.report.custom.fields', 'read', report['fields_id'], context=context)

		pageSize=common.pageSize.get(report['print_format'], [210.0,297.0])
		if report['print_orientation']=='Landscape':
			pageSize=[pageSize[1],pageSize[0]]

		tmpl = '<?xml version="1.0" encoding="ISO-8859-1"?>\n<report>\n'
		tmpl += '<config>\n'
		tmpl += '\t<date>%s</date>\n' % (time.strftime('%d/%m/%Y'),)
		tmpl += '\t<pageSize>%.2fmm,%.2fmm</pageSize>\n' % tuple(pageSize)
		tmpl += '\t<pageWidth>%.2f</pageWidth>\n' % (pageSize[0] * 2.8346,)
		tmpl += '\t<pageHeight>%.2f</pageHeight>\n' % (pageSize[1] * 2.8346,)
		if report['totalonly']:
			tmpl += '\t<totalonly>1</totalonly>\n'
		if report['groupby']:
			tmpl += '\t<groupby>%s</groupby>\n' % (report['groupby'],)

		length = pageSize[0]-30-reduce(lambda x,y:x+(y['width'] or 0), fields, 0)
		count = 0
		for f in fields:
			if not f['width']: count+=1
		for f in fields:
			if not f['width']:
				f['width']=round((float(length)/count)-0.5)

		tmpl += '\t<tableSize>%s</tableSize>\n' % ','.join(map(lambda x: '%.2fmm' % (x['width'],), fields))

		tmpl += '\t<report-header>%s</report-header>\n' % (report['title'],)
		tmpl += '\t<report-footer>%s</report-footer>\n' % (report['footer'],)
		tmpl += '</config>\n'
		
		tmpl += '<header>\n'
		for f in fields:
			tmpl += '\t<field>%s</field>\n' % (f['string'],)
		tmpl += '</header>\n'


		group = {}
		if report['groupby']:
			datas  = service.execute(uid, report['model'], 'read', ids, [report['groupby']])
			for d in datas:
				if d[report['groupby']] not in group:
					group[d[report['groupby']]] = [d['id']]
				else:
					group[d[report['groupby']]].append(d['id'])
		else:
			group[False] = ids

		keys = group.keys()
		keys.sort()
		for k in keys:
			tmpl+='<group>\n'
			ids = group[k]
			def _xml_get(ids, level=0):
				tmpl = ''
				results  = service.execute(uid, report['model'], 'read', ids, [f['name'] for f in fields]+[report['child_ids']])
				for r in results:
					tmpl+='<record>\n'
					level_ok = True
					for f in fields:
						attrs = {'id':f['name']}
						if f['calc_sum']:
							attrs['sum']='1'
						if f['calc_avg']:
							attrs['avg']='1'
						if f['calc_count']:
							attrs['count']='1'
						if report['child_ids'] and level_ok:
							attrs['level']='          '*level
							level_ok=False
						tmpl += '\t<field'
						for a in attrs:
							tmpl+=' %s="%s"' % (a,attrs[a])
						tmpl += '>'
						if type(r[f['name']]) in (type(''), type(u'')):
							tmpl += r[f['name']].replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
						else:
							tmpl += str(r[f['name']])
						tmpl += '</field>\n'
					tmpl+='</record>\n'
					if report['child_ids']:
						res = r.get(report['child_ids'],[])
						if res:
							tmpl+=_xml_get(res, level+1)
				return tmpl
			tmpl+=_xml_get(ids)
			tmpl+='</group>\n'
		tmpl+='</report>'

		file('/tmp/terp.xml','w+').write(tmpl)

		(fp_in,fp_out) = os.popen2('/usr/bin/sabcmd '+os.path.join(tools.config['root_path'], 'addons/base/report/custom.xsl'))
		fp_in.write(tmpl)
		fp_in.close()
		rml = fp_out.read()
		fp_out.close()

		self.obj = render.rml(rml)
		self.obj.render()
		return True
report_custom('report.custom')

