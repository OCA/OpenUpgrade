##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#
# $Id: interface.py 964 2005-07-18 06:35:12Z nicoe $
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import os,re

import libxml2
import libxslt
from xml import dom

import netsvc
import sql_db

import tools
import print_xml
import render

#encode to a string in utf8
def toxml(val):
	if isinstance(val, str):
		str_utf8 = val
	elif isinstance(val, unicode):
		str_utf8 = val.encode('utf-8')
	else:
		str_utf8 = str(val)
	return str_utf8.replace('&', '&amp;').replace('<','&lt;').replace('>','&gt;')

class report_int(netsvc.Service):
	def __init__(self, name, audience='*'):
		super(report_int, self).__init__(name, audience)
		if name[0:7]<>'report.':
			raise 'ConceptionError, bad report name'
		self.name = name
		self.name2 = '.'.join(name.split('.')[1:])
		self.joinGroup('report')
		self.exportMethod(self.create)
		self.exportMethod(self.args_get)
		self.exportMethod(self.result)
		self.obj = False

	def result(self):
		if self.obj and self.obj.is_done():
			return (True, self.obj.get(), self.obj.output_type)
		else:
			return (False, False, False)

	def create(self, uid, ids, datas):
		return False

	def args_get(self):
		return {'arch': self.arch, 'name':'', 'fields': {}}

"""
	Class to automatically build a document using the transformation process:
		XML -> DATAS -> RML -> PDF
		                    -> HTML
	using a XSL:RML transformation
"""
class report_rml(report_int):
	def __init__(self, name, table, tmpl, xsl):
		super(report_rml, self).__init__(name)
		self.table = table
		self.tmpl = tmpl
		self.xsl = xsl
		self.bin_datas = {}
		self.generators = {'pdf' : self.create_pdf, 'html' : self.create_html}

	def create(self, uid, ids, datas, context):
#		import time
#		start_time = time.clock()
		xml = self.create_xml(uid, ids, datas, context)
#		file('/tmp/terp.xml','wb+').write(xml)
#		mid_time1 = time.clock()
		rml = self.create_rml(xml, uid, context)
#		file('/tmp/terp.rml','wb+').write(rml)
#		mid_time2 = time.clock()
		create_doc = self.generators[datas.get('report_type','pdf')]
		pdf = create_doc(rml)
#		end_time = time.clock()

#		print '='*60
#		print "xml:", mid_time1-start_time
#		print "rml:", mid_time2-mid_time1
#		print "pdf:", end_time-mid_time2
#		print "total:", end_time-start_time

		return pdf 
	
	def	create_xml(self, uid, ids, datas, context={}):
		doc = print_xml.document(uid, datas, {})
		self.bin_datas = doc.bin_datas
		doc.parse(self.tmpl, ids, self.table)
		xml = doc.xml_get()
		doc.close()
		return self.post_process_xml_data(uid, xml)
#		return xml

	def post_process_xml_data(self, uid, xml):
		service = netsvc.LocalService("object_proxy")
		user = service.execute(uid, 'res.users', 'read', [uid], ['address_id', 'signature'])[0]

		if not user['address_id']:
			return xml
			
		contact = service.execute(uid, 'res.partner.address', 'read', [user['address_id'][0]])[0]
		
		if not contact['partner_id']:
			return xml

		partner = service.execute(uid, 'res.partner', 'read', [contact['partner_id'][0]])[0]
	
		if contact['country']:
			country = service.execute(uid, 'res.country', 'read', [contact['country'][0]])[0]
		else:
			country = {'name':''}
			
		if contact['state']:
			state = service.execute(uid, 'res.country.state', 'read', [contact['state'][0]])[0]
		else:
			state = {'name':''}
		
		iter = re.finditer('<[^>]*>', xml)
		i = iter.next()
		i = iter.next()
		pos = i.end()
		
		corporate_header = '''
	<corporate-header>
		<corporation>
			<title>%s</title>
			<name>%s</name>
			<bank>%s</bank>
			<vat>%s</vat>
			<website>%s</website>
		</corporation>
		<person>
			<title>%s</title>
			<name>%s</name>
			<street>%s</street>
			<street2>%s</street2>
			<city>%s</city>
			<zip>%s</zip>
			<country>%s</country>
			<state>%s</state>
			<email>%s</email>
			<phone>%s</phone>
			<fax>%s</fax>
			<mobile>%s</mobile>
			<signature>%s</signature>
		</person>
	</corporate-header>''' % (
			toxml(partner['title']), toxml(partner['name']), toxml(partner['bank']), toxml(partner['vat']), toxml(partner['website']), 
			toxml(contact['title']), toxml(contact['name']), toxml(contact['street']), toxml(contact['street2']), toxml(contact['city']),
			toxml(contact['zip']), toxml(country['name']), toxml(state['name']), toxml(contact['email']), toxml(contact['phone']), toxml(contact['fax']), 
			toxml(contact['mobile']), toxml(user['signature']) )
			
		return xml[:pos] + corporate_header + xml[pos:]	

	#
	# TODO: The translation doesn't work for "<tag t="1">textext<tag> tex</tag>text</tag>"
	#
	def create_rml(self, xml, uid, context={}):
		service = netsvc.LocalService("object_proxy")

		# load XSL (parse it to the XML level)
		styledoc = libxml2.parseFile(os.path.join(tools.config['root_path'],self.xsl))
		
#TODO: get all the translation in one query. That means we have to: 
# * build a list of items to translate, 
# * issue the query to translate them,
# * (re)build/update the stylesheet with the translated items

		# translate the XSL stylesheet
		def look_down(child, lang):
			while child is not None:
				if (child.type == "element") and child.hasProp('t'):
					res = service.execute(uid, 'ir.translation', '_get_source', self.name2, 'xsl', lang, child.content)
					if res:
						child.setContent(res)
				look_down(child.children, lang)
				child = child.next

		if context.get('lang',False):
			look_down(styledoc.children, context['lang'])

		style = libxslt.parseStylesheetDoc(styledoc)			# parse XSL

		doc = libxml2.parseMemory(xml,len(xml))					# load XML (data)
		result = style.applyStylesheet(doc, None)				# create RML (apply XSL to XML data)
		xml = style.saveResultToString(result)					# save result to string
		
		style.freeStylesheet()
		doc.freeDoc()
		result.freeDoc()
		return xml
	
	def create_pdf(self, xml):
		self.obj = render.rml(xml, self.bin_datas)
		self.obj.render()
		return True

	def create_html(self, xml):
		self.obj = render.rml2html(xml, self.bin_datas)
		self.obj.render()
		return True

def register_all():
	opj=os.path.join
	cr=sql_db.db.cursor()
	cr.execute("SELECT * FROM ir_act_report_xml WHERE auto ORDER BY id")
	result = cr.dictfetchall()
	cr.close()
	for r in result:
		report_rml('report.'+r['report_name'], r['model'], opj('addons',r['report_xml']), opj('addons',r['report_xsl']))

