##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import netsvc
import copy

import ir
import sql_db

class except_wizard(Exception):
	def __init__(self, name, value):
		self.name = name
		self.value = value

class interface(netsvc.Service):
	states = {}
	def __init__(self, name):
		netsvc.Service.__init__(self, 'wizard.'+name)
		self.exportMethod(self.execute)
		self.wiz_name = name

	def execute(self, uid, datas, state='init'):
		try:
			res = {}
			# iterate through the list of actions defined for this state and execute them
			# these actions are methods of the form: method(self, uid, datas)
			for act in self.states[state].get('actions', []):
				res2 = act(self, uid, datas)
				res.update( res2 )
				
			st = self.states[state]['result']
			st['datas'] = res
			
			if st['type'] == 'choice':
				method = st.get('next_state', None)
				if method:
					next_state = method(self, uid, datas)
				else:
					next_state = 'end'
				return self.execute(uid, datas, next_state)
			
			if 'fields' in st:
				st['fields'] = copy.copy(st['fields'])
				for val in st['fields'].keys():
					if 'default' in st['fields'][val]:
						st['fields'][val]['value'] = st['fields'][val]['default'](uid,datas,state)
						del st['fields'][val]['default']
					else:
						cr = sql_db.db.cursor()
						res = ir.ir_get(cr, uid, [('default', 'wizard.'+self.wiz_name), ('field', val)], [('user_id',str(uid))])
						cr.close()
						if res:
							st['fields'][val]['value']=res[0][2]
			
			return st
		except except_wizard, e:
			self.abortResponse(2, e.name, 'warning', e.value)

