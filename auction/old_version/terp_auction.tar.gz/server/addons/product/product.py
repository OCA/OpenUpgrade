##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields
from osv import osv
import math

#----------------------------------------------------------
# Categories
#----------------------------------------------------------
class product_category(osv.osv):
	_name = "product.category"
	_table = "product_category"
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'parent_id': fields.many2one('product.category','Parent Category'),
		'child_id': fields.one2many('product.category', 'parent_id', string='Childs Categories')
	}
	def child_get(self, cr, uid, ids):
		return [ids]
product_category()

#----------------------------------------------------------
# Products
#----------------------------------------------------------
class product_template(osv.osv):
	_name = "product.template"
	_table = "product_template"
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'description': fields.text('Description'),
		'type': fields.selection([('product','Stockable Product'),('finance','Financial Product'),('service','Service')], 'Product Type', required=True),
		'seller_id': fields.many2one('res.partner', 'Retailer'),
		'categ_id': fields.many2one('product.category','Category'),
		'list_price': fields.float('List Price', required=True),
		'cost_method': fields.selection([('standard','Standard Price'), ('pmp','PMP')], 'Costing Method'),
		'standard_price': fields.float('Standard Price', required=True),
		'limit_price': fields.float('Limit Price', required=True),
		'taxes_id': fields.many2many('account.tax', 'product_taxes_rel', 'prod_id', 'tax_id', 'Product Taxes'),
	}
	_defaults = {
		'type': lambda x,y,z: 'product',
		'list_price': lambda x,y,z: 1,
		'standard_price': lambda x,y,z: 1,
		'limit_price': lambda x,y,z: 1
	}
product_template()

#class product_product_location(osv.osv):
	#def _amount_get(self, cr, uid, ids, prop, unknow_none,context = {}):
		#print 'CONTEXT', context
		#result = {}
		#for id in ids:
			#result[id] = 0.0
		#if not 'product_id' in context:
			#return result
		#loc_ids = {}
		#for l in self.pool.get('stock.location').read(cr, uid, ids, ['lot_id']):
			#loc_ids[l['lot_id']] = l['id']
		#res = self.pool.get('stock.lot').product_get(cr, uid, loc_ids.keys(), [context['product_id']])
		#for r in res:
			#result[loc_ids[r]] = res[r]
		#return result
	#_name = "product.product.location"
	#_table = "product_product_location"
	#_auto = False
	#_columns = {
		#'name': fields.char('Lot Content', size=64),
		#'product_id': fields.many2one('product.product', 'Product'),
		#'location_id':fields.many2one('stock.location', 'Location'),
		#'amount': fields.function(_amount_get, method=True, string='Quantity'),
	#}
	#def init(self, cr):
		#cr.execute("CREATE OR REPLACE VIEW product_product_location AS SELECT l.id,o.name AS name,l.id AS location_id, p.id AS product_id FROM stock_location l LEFT JOIN stock_lot o ON (l.lot_id=o.id), product_product p")
		#cr.commit()
#product_product_location()

class product_product(osv.osv):
	def _product_price(self, cr, uid, ids, name, arg, context={}):
		res = {}
		quantity = context.get('quantity', 1)
		pricelist = context.get('pricelist', False)
		if pricelist:
			for id in ids:
				price = self.pool.get('product.pricelist').price_get(cr,uid,[pricelist], id, quantity, 'list')[pricelist]
				res[id] = price
		for id in ids:
			res.setdefault(id, 0.0)
		return res

	def _product_virtual_available(self, cr, uid, ids, name, arg, context={}):
		if 'shop' in context:
			cr.execute('select warehouse_id from sale_shop where id=%d', (int(context['shop']),))
			res = cr.fetchone()
			if res:
				context['warehouse'] = res[0]
		if 'warehouse' in context:
			cr.execute('select lot_stock_id from stock_warehouse where id=%d', (int(context['warehouse']),))
			res = cr.fetchone()
			if not res:
				raise 'shop_warehouse', 'Your shop has no warehouse defined !'
			context['location'] = res[0]

		if 'location' in context:
			cr.execute('select lot_id from stock_location where id=%d', (context['location'],))
			context['lot'] = cr.fetchone()[0]
		if 'lot' in context:
			res = self.pool.get('stock.lot').product_available_get(cr, uid, [context['lot']], ids)
		else:
			res = 'select product_id,sum(amount) from stock_lot_line_view where product_id in ('+','.join(map(str,ids))+') group by product_id'
			cr.execute('select product_id,sum(amount) from stock_lot_line_view where product_id in ('+','.join(map(str,ids))+') group by product_id')
			res = dict(cr.fetchall())

		for id in ids:
			res.setdefault(id, 0)
		return res

	def _product_qty_available(self, cr, uid, ids, name, arg, context={}):
		if 'shop' in context:
			cr.execute('select warehouse_id from sale_shop where id=%d', (int(context['shop']),))
			res = cr.fetchone()
			if res:
				context['warehouse'] = res[0]
		if 'warehouse' in context:
			cr.execute('select lot_stock_id from stock_warehouse where id=%d', (int(context['warehouse']),))
			res = cr.fetchone()
			if not res:
				raise 'shop_warehouse', 'Your shop has no warehouse defined !'
			context['location'] = res[0]

		if 'location' in context:
			cr.execute('select lot_id from stock_location where id=%d', (context['location'],))
			context['lot'] = cr.fetchone()[0]
		if 'lot' in context:
			res = self.pool.get('stock.lot').product_get(cr, uid, [context['lot']], ids)
		else:
			res = 'select product_id,sum(amount) from stock_lot_line_view where product_id in ('+','.join(map(str,ids))+') group by product_id'
			cr.execute('select product_id,sum(amount) from stock_lot_line_view where product_id in ('+','.join(map(str,ids))+') group by product_id')
			res = dict(cr.fetchall())

		for id in ids:
			res.setdefault(id, 0)
		return res

	_defaults = {
		'active': lambda x,y,z: 1
	}
	_name = "product.product"
	_table = "product_product"
	_inherits = {'product.template': 'product_tmpl_id'}
	_columns = {
		'qty_available': fields.function(_product_qty_available, method=True, type='integer', string='Real Stock'),
		'virtual_available': fields.function(_product_virtual_available, method=True, type='integer', string='Virtual Stock'),
		'price': fields.function(_product_price, method=True, type='float', string='Customer Price'),
		'code': fields.char('Code', size=64),
		'active': fields.boolean('Active'),
		'variants': fields.char('Variants', size=64),
		'list_price_margin': fields.float('List Price Margin'),
		'list_price_extra': fields.float('List Price Extra'),
		'standard_price_margin': fields.float('Standard Price Margin'),
		'standard_price_extra': fields.float('Standard Price Extra'),
		'limit_price_margin': fields.float('Limit Price Margin'),
		'limit_price_extra': fields.float('Limit Price Extra'),
		'product_tmpl_id': fields.many2one('product.template', 'Product Template', required=True),
	}
	def on_order(self, cr, uid, ids, orderline, quantity):
		pass

	def name_get(self, cr, user, ids, context={}):
		if not len(ids):
			return []
		result = [ (r['id'], str(r['name'])+((r['variants'] or '') and ' - '+r['variants'])) for r in self.read(cr, user, ids, ['name','variants'])]
		return result

	def name_search(self, cr, user, name, args=[], operator='ilike', context={}):
		ids = self.search(cr, user, [('name',operator,name)]+ args)
		ids += self.search(cr, user, [('code','=',name)]+ args)
		return self.name_get(cr, user, ids)

	def price_get(self, cr, uid, ids, ptype='list'):
		result = self.read(cr, uid, ids)
		result2 = {}
		for res in result:
			result2[res['id']] = (res[ptype+'_price']*(1.0+(res[ptype+'_price_margin'] or 0.0)))+(res[ptype+'_price_extra'] or 0.0)
		return result2
product_product()

def rounding(f, r):
	return round(f, -int(math.log10(r)))

#----------------------------------------------------------
# Price lists
#----------------------------------------------------------

class product_pricelist(osv.osv):
	_name = "product.pricelist"
	_table = "product_pricelist"
	_columns = {
		'name': fields.char('Name',size=64, required=True),
		'active': fields.boolean('Active'),
		'version_id': fields.one2many('product.pricelist.version', 'pricelist_id', 'Pricelist Versions')
	}
	_defaults = {
		'active': lambda x,y,z: 1,
	}

	def price_get(self, cr, uid, ids, prod_id, qty, type='list'):
		result = {}

		# TODO FIXME 
		for id in ids:
			cr.execute('select * from product_pricelist_version where pricelist_id=%d and active=True order by id limit 1', (id,))
			plversion = cr.dictfetchone()
			if not plversion:
				raise 'pricelist', 'No active version for this pricelist !\nPlease create or active one.'

			cr.execute('select id,categ_id from product_template where id=(select product_tmpl_id from product_product where id=%d)', (prod_id,))
			tmpl_id,categ = cr.fetchone()
			categ_ids = []
			while categ:
				categ_ids.append(str(categ))
				cr.execute('select parent_id from product_category where id=%d', (categ,))
				categ = cr.fetchone()[0]
			if categ_ids:
				categ_where = '(categ_id in ('+','.join(categ_ids)+'))'
			else:
				categ_where = '(categ_id is null)'

			cr.execute('select * from product_pricelist_item where (product_tmpl_id is null or product_tmpl_id=%d) and '+categ_where+' and price_version_id=%d and (min_quantity is null or min_quantity<=%d) order by priority limit 1', (tmpl_id, plversion['id'], qty))
			res = cr.dictfetchone()
			if res:

				if res['base_pricelist_id']:
					price = self.price_get(cr, uid, [res['base_pricelist_id']], prod_id, qty, type+'_price_base')[id]
					price_limit = self.price_get(cr, uid, [res['base_pricelist_id']], prod_id, qty, 'limit_price_base')[id]
				else:
					price = self.pool.get('product.product').price_get(cr, uid, [prod_id], type)[prod_id]
					price_limit = self.pool.get('product.product').price_get(cr, uid, [prod_id], 'limit')[prod_id]

				price = price * (1.0-(res[type+'_price_discount'] or 0.0))
				if res[type+'_price_round']:
					price=rounding(price, res[type+'_price_round'])
				price += (res[type+'_price_surcharge'] or 0.0)
				if res[type+'_price_min_margin']:
					price = max(price, price_limit+res[type+'_price_min_margin'])
				if res[type+'_price_max_margin']:
					price = min(price, price_limit+res[type+'_price_max_margin'])
			else:
				price=False
			result[id] = price

		return result
product_pricelist()

class product_pricelist_version(osv.osv):
	_name = "product.pricelist.version"
	_table = "product_pricelist_version"
	_columns = {
		'pricelist_id': fields.many2one('product.pricelist', 'Price List', required=True),
		'name': fields.char('Name', size=64, required=True),
		'active': fields.boolean('Active'),
		'items_id': fields.one2many('product.pricelist.item', 'price_version_id', 'Price List Items', required=True),
		'date_start': fields.date('Start Date'),
		'date_end': fields.date('End Date')
	}
	_defaults = {
		'active': lambda x,y,z: 1,
	}
product_pricelist_version()

class product_pricelist_item(osv.osv):
	_name = "product.pricelist.item"
	_table = "product_pricelist_item"
	_order = "priority"
	_defaults = {
		'list_price_base': lambda x,y,z: 'list',
		'standard_price_base': lambda x,y,z: 'standard',
		'limit_price_base': lambda x,y,z: 'limit',
		'min_quantity': lambda x,y,z: 1,
		'priority': lambda x,y,z: 5,
	}
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'price_version_id': fields.many2one('product.pricelist.version', 'Price List Version', required=True),
		'product_tmpl_id': fields.many2one('product.template', 'Product Template'),
		'categ_id': fields.many2one('product.category', 'Product Category'),

		'min_quantity': fields.integer('Min. Quantity', required=True),
		'priority': fields.integer('Priority', required=True),
		'base': fields.selection((('product','Product'),('pricelist','Pricelist')), 'Based on', required=True),
		'base_pricelist_id': fields.many2one('product.pricelist', 'Base Price List'),

		'list_price_base': fields.selection((('list','List'),('standard','Standard'),('limit','Limit')),'List Price Base', required=True),
		'list_price_surcharge': fields.float('List Price Surcharge'),
		'list_price_discount': fields.float('List Price Discount'),
		'list_price_round': fields.float('List Price Rounding'),
		'list_price_min_margin': fields.float('List Price Min. Margin'),
		'list_price_max_margin': fields.float('List Price Max. Margin'),

		'standard_price_base': fields.selection((('list','List'),('standard','Standard'),('limit','Limit')),'Standard Price Base', required=True),
		'standard_price_surcharge': fields.float('Standard Price Surcharge'),
		'standard_price_discount': fields.float('Standard Price Discount'),
		'standard_price_round': fields.float('Standard Price Rounding'),
		'standard_price_min_margin': fields.float('Standard Price Min. Margin'),
		'standard_price_max_margin': fields.float('Standard Price Max. Margin'),

		'limit_price_base': fields.selection((('list','List'),('standard','Standard'),('limit','Limit')),'Limit Price Base', required=True),
		'limit_price_surcharge': fields.float('Limit Price Surcharge'),
		'limit_price_discount': fields.float('Limit Price Discount'),
		'limit_price_round': fields.float('Limit Price Rounding'),
		'limit_price_min_margin': fields.float('Limit Price Min. Margin'),
		'limit_price_max_margin': fields.float('Limit Price Max. Margin'),
	}
product_pricelist_item()

