{
	"name" : "Tiny TERP Products",
	"version" : "1.0",
	"depends" : ["base","account"],
	"init_xml" : [ "product_data.xml", "product_demo.xml"],
	"update_xml" : [ "product_view.xml"],
	"active": True
}
