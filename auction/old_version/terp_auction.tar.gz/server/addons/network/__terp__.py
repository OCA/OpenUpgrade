{
	"name" : "Tiny TERP Network Management",
	"version" : "1.0",
	"depends" : ["base"],
	"init_xml" : ['network_demo.xml'],
	"update_xml" : ["network_view.xml",'network_report.xml'],
	"active" : True
}
