{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ["base", "account"],
	"update_xml" : ["huissier_report.xml", "huissier_wizard.xml", "huissier_view.xml"],
	"init_xml" : [ "huissier_data.xml", "huissier_demo.xml"],
}
