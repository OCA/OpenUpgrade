# -*- encoding: iso-8859-1 -*-
##############################################################################
#
# Copyright (c) 2005 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import time

import netsvc
from osv import fields, osv, orm
import ir

#----------------------------------------------------------
# Dossier
#----------------------------------------------------------
class huissier_dossier(osv.osv):
	_name = "huissier.dossier"
	_auto = True
	_rec_name = 'num_vignette'

	def _adjudication_get(self, cr, uid, ids, prop=None, unknown_none=None, unknown_dict={}):
		res = {}
		for id in ids:
			res[id]=0.0
			cr.execute("select sum(adj_price) from huissier_lots where dossier_id=%d", (id,))
			sum = cr.fetchone()
#			print "adj_get sum", sum
			res[id] = sum and sum[0] or 0.0
#			print "adj_get res", res[id]
		return res
		
	def _costs_get(self, cr, uid, ids, prop=None, unknown_none=None, unknown_dict={}):
		dossiers = self.browse(cr, uid, ids)
		res = {}
		for d in dossiers:
			costs = [l.amount_costs for l in d.lot_id]
#			print costs
			cost_amount = reduce(lambda x, y: x+y, costs, 0.0)
#			print cost_amount
			res[d.id] = cost_amount 
		return res

	def _total_get(self, cr, uid, ids, prop=None, unknown_none=None, unknown_dict={}):
		res = {}
		for id in ids:
			adj = self._adjudication_get(cr, uid, [id])[id] 
			costs = self._costs_get(cr, uid, [id])[id]
#			print "total_get", adj, costs
			res[id] = adj + costs
		return res
		
	def _room_costs_get(self, cr, uid, ids, prop=None, unknown_none=None, unknown_dict={}):
		dossiers = self.browse(cr, uid, ids)
		res = {}
		for d in dossiers:
			total = self._adjudication_get(cr, uid, [d.id])[d.id]
			costs = self.pool.get('account.tax').compute(cr, uid, [d.room_cost_id.id], total, 1)
			res[d.id] = reduce(lambda x, y: x+y['amount'], costs, 0.0)
		return res

	_columns = {
#		'name': fields.integer(u'Num�ro de vignette'),
		'num_vignette': fields.integer(u'Num�ro de vignette'),

		
		'etude_id': fields.many2one('res.partner', u'Etude', domain="[('category_id','=','Etudes')]", required=True),

		'date_creation': fields.date(u'Cr�ation'),

		'creancier': fields.many2one('res.partner', u'Cr�ancier'),
#		'creancier_name': fields.char('Nom', size=64),
#		'creancier_address': fields.char('Adresse', size=128),
#		'creancier_zip': fields.char('Code postal', change_default=True, size=24),
#		'creancier_city': fields.char('Ville', size=64),

		'debiteur': fields.many2one('res.partner', u'D�biteur'),
#		'debiteur_name': fields.char('Nom', size=64),
#		'debiteur_address': fields.char('Adresse', size=128),
#		'debiteur_zip': fields.char('Code postal', change_default=True, size=24),
#		'debiteur_city': fields.char('Ville', size=64),

#		'debiteur_naissance': fields.date('Date de naissance'),
#		'debiteur_tva':fields.char('TVA', size=32),
		
		'date_prevue': fields.date(u'Date pr�vue'),
		'date_reelle': fields.date(u'Date r�elle'),
		
		'lang': fields.selection((('fr',u'Fran�ais'),('nl',u'N�erlandais')), u'Langue', required=True),
		
		'cost_id': fields.many2one('account.tax', u'Frais de Vente', domain="[('domain','=','frais')]", required=True),
		'room_cost_id': fields.many2one('account.tax', u'Frais de Salle', domain="[('domain','=','salle')]", required=True),

		'amount_adj': fields.function(_adjudication_get, method=True, string=u'Adjudications'),
		'amount_costs': fields.function(_costs_get, method=True, string=u'Frais'),
		'amount_total': fields.function(_total_get, method=True, string=u'Total'),
		'amount_room_costs': fields.function(_room_costs_get, method=True, string=u'Frais de salle'),
		
		'state': fields.selection((('draft',u'Ouvert'),('closed',u'Ferm�')), u'�tat', readonly=True),

		'lot_id': fields.one2many('huissier.lots', 'dossier_id', u'Objets'),
		'invoice_id': fields.many2one('account.invoice', u'Facture'),
		'income_account_id': fields.many2one('account.account', 'Compte Revenus', required=True),
#		'expense_account_id': fields.many2one('account.account', 'Expense Account', required=True),
		'deposit_id': fields.one2many('huissier.deposit', 'dossier_id', u'Garde meuble'),
		
	}
	_defaults = {
		'state': lambda uid, page, ref: 'draft',
		'date_creation': lambda x,y,z: time.strftime('%Y-%m-%d'),
#		'etat_garde_meuble': lambda obj,cr,uid: 'draft',
	}
	
	def name_get(self, cr, uid, ids, context={}):
		if not len(ids):
			return []
		
		res = []
		for r in self.read(cr, uid, ids, ['num_vignette','etude_id']):
			name = str(r['etude_id'][1]) or ''
			if r['num_vignette']:
				name += ' (vignette %d)' % r['num_vignette']
			res.append((r['id'], name))
		return res

	def onchange_num_vignette(self, cr, uid, ids, num):
		cr.execute("select id,name from res_partner where id=(select etude_id from huissier_vignettes where %d >= first and %d <= last)", (num,num))
		res = cr.dictfetchall()
		if len(res)==0:
			return {}
		return {'value':{'etude_id':(res[0]['id'], res[0]['name'])}}

#	def close(self, cr, uid, ids, *args):
#		"""
#		Close a date.
#	
#		Create invoices for all buyers and sellers.
#	
#		facture pour 
#			garde meuble
#				voirie -> execption si pa
#			salle
#		pour 
#		
#		STATE = 'close'
#	
#		RETURN: True
#		"""
#		pass
		
	def invoice(self, cr, uid, ids, frais_voirie=False):
#FIXME: la question est: faudrait pas stocker les frais de voirie ds l'objet
#a la place de le demander ds le wizard? C plus pratique pour refaire invoice
		"""
			Create an invoice for selected range of objects (ids)
		"""
		dt = time.strftime('%Y-%m-%d')
#		print "voirie", frais_voirie
		dossiers = self.browse(cr, uid, ids)
		if not len(dossiers):
			return []
			
		frais_salle_str = {
			'fr': u'Frais de salle',
			'nl': u'Zaalkosten',
		}
		
		frais_voirie_str = {
			'fr': u'Frais de voirie',
#FIXME:
			'nl': u'Zaalkosten',
		}

		for dossier in dossiers:
			invoice_desc = u'Facture de salle'
			etude = dossier.etude_id
			lang = etude.lang or 'fr'
			print 'lang', lang

			account_receive_id = ir.ir_get(cr,uid,[('meta','res.partner'), ('name','account.receivable')], [('id',str(etude.id))] )[0][2]
			lines = []
			
			line_desc = frais_salle_str[lang]
			if dossier.num_vignette:
				invoice_desc += ' (%d)' % dossier.num_vignette
				line_desc += ' (%d)' % dossier.num_vignette
			if dossier.debiteur:
				line_desc += ' %s' % dossier.debiteur.name
#CHECKME: fo des taxes pour les vignettes?
			print "amount_room_costs", dossier.amount_room_costs
			lines.append((0,False, {'name':line_desc, 'quantity':1, 'account_id':dossier.income_account_id, 'price_unit':dossier.amount_room_costs}))

			if frais_voirie:
				line_desc = frais_voirie_str[lang]
				lines.append((0,False, {'name':line_desc, 'quantity':1, 'account_id':dossier.income_account_id, 'price_unit':frais_voirie}))
				
			addr = self.pool.get('res.partner').address_get(cr, uid, [etude.id], ['contact','invoice'])
			number = self.pool.get('ir.sequence').get(cr, uid, 'huissier.invoice.salle')

			new_invoice = {
				'name': invoice_desc,
				'number': number,
				'state': 'draft',
				'partner_id': etude.id,
				'address_contact_id': addr['contact'],
				'address_invoice_id': addr['invoice'],
				'partner_ref': etude.ref,
				'date_invoice': dt,
				'date_due': dt,
				'invoice_line': lines,
				'type': 'out_invoice',
				'account_id': account_receive_id,
			}

			invoice_id = self.pool.get('account.invoice').create(cr, uid, new_invoice)

#			number = self.pool.get('ir.sequence').get(cr, uid, 'huissier.invoice.salle')
#			cr.execute('UPDATE account_invoice SET number=%s WHERE id=%d', (number,invoice_id))
			
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'account.invoice', invoice_id, 'invoice_open', cr)
#FIXME: vu le return, la boucle sur les dossiers sert plus a rien
			return invoice_id
		
	def close(self, cr, uid, ids, frais_voirie=False):
		for id in ids:
			invoice_id = self.invoice(cr, uid, [id], frais_voirie)
			self.write(cr, uid, [id], {'invoice_id':invoice_id, 'state':'closed'})
			
huissier_dossier()

#----------------------------------------------------------
# (Specific) Deposit Costs
#----------------------------------------------------------
#class huissier_deposit_cost(osv.osv):
#	_name = 'huissier.deposit.cost'
#	_auto = True
#	_columns = {
#		'name': fields.char('Cost Name', required=True, size=64),
#		'amount': fields.float('Amount'),
#		'account': fields.many2one('account.account', 'Destination Account', required=True),
#		'deposit_id': fields.many2one('huissier.deposit', 'Deposit'),
#	}
#huissier_deposit_cost()

def _lang_get(self, cr, user):
	cr.execute('select code, name from res_lang order by name')
	return cr.fetchall()+[(False, '/')]
#----------------------------------------------------------
# Lots
#----------------------------------------------------------
class huissier_lots(osv.osv):
	_name = "huissier.lots"
	_auto = True
	_order = "number"

	def _get_price_wh_costs(self, cr, uid, ids, name, arg, context):
		res = {}
		cr.execute("select id, dossier_id, adj_price from huissier_lots where id in ("+','.join([str(id) for id in ids])+")")
		for (id, dossier, price) in cr.fetchall():
#FIXME: there is a bug somewhere: the 0.0 from a spinint gets saved as a None value in the DB :(
			if not price:
				price = 0.0
			res[id] = price + self.get_costs_amount(cr, uid, ids, dossier, price)
		return res

	def _get_costs(self, cr, uid, ids, name, arg, context):
		res = {}
		cr.execute("select id, dossier_id, adj_price from huissier_lots where id in ("+','.join([str(id) for id in ids])+")")
		for (id, dossier, price) in cr.fetchall():
#FIXME: there is a bug somewhere: the 0.0 from a spinint gets saved as a None value in the DB :(
			if not price:
				price = 0.0
			res[id] = self.get_costs_amount(cr, uid, ids, dossier, price)
		return res

	_columns = {
		'dossier_id': fields.many2one('huissier.dossier', u'Dossier huissier'),
		'number': fields.integer(u'Lot', required=True, readonly=True),
		'name': fields.char(u'Description', size=256, required=True),
		'vat': fields.many2one('account.tax', u'Taxe', domain="[('domain','=','tva')]", required=True),
		'adj_price': fields.float(u"Prix d'adjudication"),
		
		'buyer_ref': fields.many2one('res.partner', u'R�f. client', domain="[('category_id', '=', 'Clients habituels')]"),
#		'buyer_ref': fields.char(u'R�f. client', size=64),
		'buyer_name': fields.char(u'Nom et Pr�nom', size=64),
#		'buyer_firstname': fields.char(u'Pr�nom', size=64),
		'buyer_address': fields.char(u'Adresse', size=128),
		'buyer_zip': fields.char(u'Code postal', change_default=True, size=24),
		'buyer_city': fields.char(u'Ville', size=64),
		'buyer_birthdate': fields.char(u'Date de naissance', size=64),
		'buyer_vat': fields.char(u'TVA', size=64),
		'buyer_lang': fields.selection(_lang_get, 'Langue', size=2),
		'amount_costs': fields.function(_get_costs, method=True, string=u'Frais'),
		'price_wh_costs': fields.function(_get_price_wh_costs, method=True, string=u'A payer'),
	}
	_defaults = {
		'number': lambda obj,cr,uid: obj._get_next_lot_number(cr, uid),
		'vat': lambda obj,cr,uid: obj._get_lot_default_vat(cr, uid)
	}
	
	def _get_next_lot_number(self, cr, uid):
#		return int(self.pool.get('ir.sequence').get(cr, uid, 'huissier.lots'))
		year = time.strftime('%Y')
#FIXME: ca va planter si dossier cr�e ds une annee puis 'vendu' l'ann�e suivante
#mais utiliser date_relle c'est foireux car date_relle pas forcement rempliea
		# returns the highest number used in a dossier created this year
		cr.execute("select max(number)+1 as number from huissier_lots as l left join huissier_dossier as d on l.dossier_id=d.id  where date_creation >= '%s-01-01'" % (year,))
		res = cr.dictfetchall()
		return res[0]['number'] or 1

	def _get_lot_default_vat(self, cr, uid):
		year = time.strftime('%Y')
		# returns the vat used in the lot with the highest number in dossiers created this year
		query = "select vat from huissier_lots as l left join huissier_dossier as d on l.dossier_id=d.id " \
				"where number =	(select max(number) " \
								"from huissier_lots as l left join huissier_dossier as d on l.dossier_id=d.id " \
								"where date_creation >= '%s-01-01')" \
				"and date_creation >= '%s-01-01'" % (year,year)
		cr.execute(query)
		res = cr.dictfetchall()
		#TODO: comment what happens when none is found
		print "default_vat_res", res[0]['vat']
		return res[0]['vat']

	def get_costs_amount(self, cr, uid, ids, dossier_id, adj_price):
		dossier = self.pool.get('huissier.dossier').read(cr, uid, [dossier_id], ['cost_id'])[0]
		costs = self.pool.get('account.tax').compute(cr, uid, [dossier['cost_id'][0]], adj_price, 1)
		cost_amount = reduce(lambda x, y: x+y['amount'], costs, 0.0)
		return cost_amount
	
	def onchange_adj_price(self, cr, uid, ids, dossier_id, adj_price):
		print "onchange_adj_price", dossier_id, adj_price
		return {'value':{'price_wh_costs': adj_price + self.get_costs_amount(cr, uid, ids, dossier_id, adj_price)}}
		
	def onchange_buyer_ref(self, cr, uid, ids, buyer_id):
#		cr.execute('select id from res_partner where ref=%s', (buyer_ref,)) # and category = client
#		res = cr.dictfetchall()
#		if not len(res):
		if not buyer_id:
			return {
				'value': {'buyer_name':False, 'buyer_address':False, 'buyer_zip':False, 'buyer_city':False, 'buyer_birthdate':False, 'buyer_vat':False, 'buyer_lang':False},
				'readonly': {'buyer_name':False, 'buyer_address':False, 'buyer_zip':False, 'buyer_city':False, 'buyer_birthdate':False, 'buyer_vat':False, 'buyer_lang':False}
			}
		partner = self.pool.get('res.partner').browse(cr, uid, buyer_id)
		address = partner.address[0]
		return {
			'value': {'buyer_name':partner.name, 'buyer_address':address.street, 'buyer_zip':address.zip, 'buyer_city':address.city, 'buyer_birthdate':address.birthdate, 'buyer_vat':partner.vat, 'buyer_lang':partner.lang},
			'readonly': {'buyer_name':True, 'buyer_address':True, 'buyer_zip':True, 'buyer_city':True, 'buyer_birthdate':True, 'buyer_vat':True, 'buyer_lang':True}
		}
		

huissier_lots()

class huissier_vignettes(osv.osv):
	_name = "huissier.vignettes"
	_auto = True
	_order = "first"
	
	def _get_range_value(self, cr, uid, ids, name, arg, context):
		res = {}
		cr.execute("select id, price, quantity from huissier_vignettes where id in ("+','.join([str(id) for id in ids])+")")
		for (id, price, quantity) in cr.fetchall():
#FIXME: there is a bug somewhere: the 0.0 from a spinint gets saved as a None value in the DB :(
#			if not price:
#				price = 0.0
			res[id] = price * quantity
		return res
		
	_columns = {
#		'test_int1': fields.integer(u'Test int 1', states={'draft':[('required',True)], 'invoiced':[('required',False)]}),
#		'test_int2': fields.integer(u'Test int 2', states={'draft':[('required',False)], 'invoiced':[('required',True)]}),
#		'test_float1': fields.float(u'Num�ro float 1', states={'draft':[('required',True)], 'invoiced':[('required',False)]}),
#		'test_float2': fields.float(u'Num�ro float 2', states={'draft':[('required',False)], 'invoiced':[('required',True)]}),
		
		'etude_id': fields.many2one('res.partner', u'Etude', domain="[('category_id', '=', 'Etudes')]", required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'price': fields.float(u'Prix unitaire', required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'quantity': fields.integer(u'Quantit�', required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'first': fields.integer(u'R�f�rence de d�part', required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'last': fields.integer(u'R�f�rence de fin', required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'acquis': fields.boolean(u'Pour acquis', states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
		'invoice_id': fields.many2one('account.invoice', u'Facture', readonly=True),
		'transfer_id': fields.many2one('account.transfer', u'Payement', readonly=True),
		'income_account_id': fields.many2one('account.account', 'Compte Revenus', required=True, states={'invoiced':[('readonly',True)],'paid':[('readonly',True)]}),
#		'state': fields.selection( (('draft',u'draft'),('waiting',u'en attente'),('invoiced',u'factur�es')),u'�tat', readonly=True),
		'state': fields.selection( (('draft',u'draft'),('invoiced',u'factur�es'),('paid',u'pay�es')),u'�tat', readonly=True),
		'value': fields.function(_get_range_value, method=True, string=u'A payer'),
	}
	_defaults = {
		'price': lambda obj,cr,uid: 11.0,
		'first': lambda obj,cr,uid: obj._get_next_first_number(cr, uid),
		'state': lambda obj,cr,uid: 'draft',
	}

	def _get_next_first_number(self, cr, uid):
		cr.execute('select max(last)+1 as number from huissier_vignettes')
		res = cr.dictfetchall()
		return res[0]['number'] or 1
		
	def onchange_quantity(self, cr, uid, ids, quantity, first):
		return {'value':{'last':first + quantity - 1}}
		
	def onchange_last(self, cr, uid, ids, first, last):
		if last < first:
			return {}
		else:
			return {'value':{'quantity':last - first + 1}}
	
	def pay(self, cr, uid, ids, account_id):
		label_ranges = self.browse(cr, uid, ids)
		if not len(label_ranges):
			return []
		
		for lr in label_ranges:
			partner_id = lr.etude_id.id
			account_src_id = ir.ir_get(cr,uid,[('meta','res.partner'), ('name','account.receivable')], (partner_id or []) and [('id',str(partner_id))] )[0][2]
			transfer_name = u'Payement des vignettes %d � %d (%d vignettes)' % (lr.first, lr.last, lr.quantity)
			transfer = {
				'name': transfer_name,
				'partner_id': partner_id,
				'account_src_id': account_src_id,
				'type': 'in_payment',
				'account_dest_id': account_id,
				'amount': lr.value,
			}

			transfer_id = self.pool.get('account.transfer').create(cr, uid, transfer)
			self.pool.get('account.transfer').pay_validate(cr,uid,[transfer_id])
			
			self.write(cr, uid, [lr.id], {'transfer_id':transfer_id, 'state':'paid'})
			
	def invoice(self, cr, uid, ids):
		"""
			Create an invoice for selected range of 'vignettes' (ids)
		"""
		dt = time.strftime('%Y-%m-%d')

		label_ranges = self.browse(cr, uid, ids)
		if not len(label_ranges):
			return []

#TODO; raise except if quantity == 0

		# group label ranges by etude
		# ie create a dictionary containing lists of label ranges
		label_ranges_etude = {}
		for lr in label_ranges:
			if not lr.etude_id in label_ranges_etude:
				label_ranges_etude[lr.etude_id] = []
			label_ranges_etude[lr.etude_id].append(lr)
			
#FIXME: this is ugly!!!
#		invoice_comments = {
#			'fr': u'<para>Cher Ma�tre,</para><para>Veuillez trouver ci-dessous le d�compte des montants dus � la salle de vente.</para>',
#			'nl': u'<para>Geachte Meester,</para><para>Gelieve hieronder de afrekening te willen vinden van de som verschuldigd aan de veilingzaal.</para>'
#		}
			
		line_descs = {
			'fr': u'vignette(s) (%d --> %d)',
			'nl': u'vignette(n) (%d --> %d)'
		}
		
#CHECKME: check nl !!!
		invoice_descs = {
			'fr': u'Facture de vignettes (%d vignette(s))',
			'nl': u'Vignetten factuur (%d vignette(n))'
		}
		
		# use each list of label ranges in turn
		for label_ranges in label_ranges_etude.values():
			etude = label_ranges[0].etude_id
			lang = etude.lang or 'fr'
			label_quantity = reduce(lambda total, lr: total + lr['quantity'], label_ranges, 0.0)
			invoice_desc = invoice_descs[lang] % (label_quantity,)

			print 'lang', lang
			
			account_receive_id = ir.ir_get(cr,uid,[('meta','res.partner'), ('name','account.receivable')], [('id',str(etude.id))] )[0][2]

			lines = []
			for lr in label_ranges:
				line_desc = line_descs[lang] % (lr.first, lr.last)
#CHECKME: fo des taxes pour les vignettes?
				lines.append((0,False, {'name':line_desc, 'quantity':lr.quantity, 'account_id':lr.income_account_id, 'price_unit':lr.price}))

			addr = self.pool.get('res.partner').address_get(cr, uid, [etude.id], ['contact','invoice'])

			# get the number from the sequence (we set it manually)
			number = self.pool.get('ir.sequence').get(cr, uid, 'huissier.invoice.vignettes')
			new_invoice = {
				'number': number,
				'name': invoice_desc,
#				'comment': invoice_comments[lang],
				'state': 'draft',
				'partner_id': etude.id,
				'address_contact_id': addr['contact'],
				'address_invoice_id': addr['invoice'],
				'partner_ref': etude.ref,
				'date_invoice': dt,
				'date_due': dt,
				'invoice_line': lines,
				'type': 'out_invoice',
				'account_id': account_receive_id,
			}

			invoice_id = self.pool.get('account.invoice').create(cr, uid, new_invoice)

#			if action:
#				wf_service = netsvc.LocalService("workflow")
#				wf_service.trg_validate(uid, 'account.invoice', invoice_id, action, cr)

			for lr in label_ranges:
				print "id", lr.id
				
			lr_ids = [lr.id for lr in label_ranges]
			print "ids", lr_ids
			self.write(cr, uid, lr_ids, {'invoice_id':invoice_id, 'state':'invoiced'})
huissier_vignettes()

#----------------------------------------------------------
# Deposit
#----------------------------------------------------------
class huissier_deposit(osv.osv):
	_name = "huissier.deposit"
	_auto = True
	_order = "rentree_mobilier"
	_columns = {
		'billing_partner_id': fields.many2one('res.partner', u'Partenaire � facturer', required=True),
		'dossier_id': fields.many2one('huissier.dossier', u'Dossier'),
#		'lang': fields.selection((('fr',u'Fran�ais'),('nl',u'N�erlandais')), u'Langue', required=True),
		'rentree_mobilier': fields.date(u'Mobilier rentr� le', required=True),
		'sortie_mobilier': fields.date(u'Retir� le'),
		'cubage': fields.float(u'Cubage (m�)', digits=(12,2)),
		'prix_garde_meuble': fields.float(u'Prix au m�/mois', required=True),
		'nombre_vehicule': fields.integer(u'Nombre de v�hicules'),
		'forfait_vehicule': fields.float(u'Forfait v�hicule', required=True),
		'income_account_id': fields.many2one('account.account', 'Compte Revenus', required=True),
		'state': fields.selection((('draft',u'draft'),('running',u'en cours'),('closed',u'retir�')), u'Statut', readonly=True),
	}
	_defaults = {
		'state': lambda obj,cr,uid: 'draft',
	}
	
	def invoice(self, cr, uid, ids):
		dt = time.strftime('%Y-%m-%d')

		deposits = self.browse(cr, uid, ids)

#FIXME: change texts !!
		line_descs = {
			'fr': u'garde meuble (dossier %d)',
			'nl': u'meubelbewaring (dossier %d)'
		}
		
#FIXME: change texts !!
		invoice_descs = {
			'fr': u'Facture de garde meuble',
			'nl': u'NL facture de garde meuble NL'
		}
		for deposit in deposits:
			partner_id = deposit.partner_id
			dossier_id = deposit.dossier_id.id
			lang = partner_id.lang or 'fr'
			
			
			label_quantity = reduce(lambda total, lr: total + lr['quantity'], label_ranges, 0.0)
			invoice_desc = u'Facture de vignettes (%d vignettes(s))' % (label_quantity,)
			
			account_receive_id = ir.ir_get(cr, uid, [('meta','res.partner'),('name','account.receivable')], [('id',str(partner_id))] )[0][2]


			lines = []
			line_desc = line_descs[lang] % (dossier_id,)
#CHECKME: fo des taxes pour les factures de garde?
			lines.append((0, False, {'name':line_desc, 'quantity':1, 'account_id':lr.income_account_id, 'price_unit':lr.price}))

			addr = self.pool.get('res.partner').address_get(cr, uid, [partner_id], ['contact','invoice'])

			# get the number from the sequence (we set it manually)
			number = self.pool.get('ir.sequence').get(cr, uid, 'huissier.invoice.garde')
			new_invoice = {
				'number': number,
				'name': invoice_desc,
				'state': 'draft',
				'partner_id': partner_id,
				'address_contact_id': addr['contact'],
				'address_invoice_id': addr['invoice'],
				'partner_ref': partner_id.ref,
				'date_invoice': dt,
				'date_due': dt,
				'invoice_line': lines,
				'type': 'out_invoice',
				'account_id': account_receive_id,
			}
			invoice_id = self.pool.get('account.invoice').create(cr, uid, new_invoice)
			
	def create_cron(self, cr, uid, ids):
#	_columns = {
#		'name': fields.char('Name', size=60, required=True),
#		'user_id': fields.many2one('res.users', 'User', required=True),
#		'active': fields.boolean('Active'),
#		'interval_number' : fields.integer('Interval Number'),
#		'interval_type' : fields.selection( [('minutes', 'Minutes'),
#		    ('hours', 'Hours'), ('days', 'Days'),('weeks', 'Weeks'), ('months', 'Months')], 'Interval Unit'),
#		# number of time the function is called, a negative number
#		# indicates that the function will always be called.
#		'numbercall': fields.integer('Number of calls'),
#		
#		# Repeat missed cronjobs ?
#		'doall' : fields.boolean('Repeat all missed'),
#	
#		'nextcall' : fields.datetime('Next call date', required=True),
#		'model': fields.char('Model', size=64),
#		'function': fields.char('Function', size=64),
#		'args': fields.text('Arguments'),
#	
#		# 0 = Very Urgent, 10 = not urgent
#		'priority': fields.integer('Priority (0=Very Urgent)')
#	}
#	
#	_defaults = {
#		'nextcall' : lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
#		'priority' : lambda x,y,z: 5,
#		'user_id' : lambda x,y,z: z,
#		'interval_number' : lambda x,y,z: 1,
#		'numbercall' : lambda x,y,z: 1,
#		'active' : lambda x,y,z: 1,
#		'doall' : lambda x,y,z: 1
#	}
		cron_id = self.pool.get('ir.cron').create(cr, uid, new_invoice)
		pass
huissier_deposit()


