# -*- coding: iso-8859-1 -*-
##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import time

import wizard
import netsvc
import sql_db

close_form = '''<?xml version="1.0"?>
<form title="Paid ?">
	<field name="adj"/>
	<field name="frais"/>
	<field name="total"/>
	<field name="salle"/>
	<newline/>
	<field name="voirie"/>
</form>'''

close_fields = {
	'adj': {'string':'Adjudications', 'type':'float', 'readonly':True},
	'frais': {'string':'Frais', 'type':'float', 'readonly':True},
	'total': {'string':'Total', 'type':'float', 'readonly':True},
	'salle': {'string':'Frais de salle', 'type':'float', 'readonly':True},
	'voirie': {'string':'Frais de voirie', 'type':'float'},
}

def _get_value(self, uid, datas):
	service = netsvc.LocalService("object_proxy")
	res = service.execute(uid, 'huissier.dossier', 'read', datas['ids'], ['amount_adj','amount_costs','amount_total','amount_room_costs'])
	if not len(res):
		return {}
	return {'adj':res[0]['amount_adj'], 'frais':res[0]['amount_costs'], 'total':res[0]['amount_total'], 'salle':res[0]['amount_room_costs']}

def _close_dossier(self, uid, datas):
	service = netsvc.LocalService("object_proxy")
	print datas
	service.execute(uid, 'huissier.dossier', 'close', datas['ids'], datas['form']['voirie'])
	return {}

class wizard_close_dossier(wizard.interface):
	states = {
		'init': {
			'actions': [_get_value], 
			'result': {'type': 'form', 'arch':close_form, 'fields':close_fields, 'state':[('close_dossier','Fermer le dossier'), ('end','Annuler')]}
		},
		'close_dossier': {
			'actions': [_close_dossier],
			'result': {'type': 'state', 'state':'end'}
#TODO: ptet qu'il faudrait imprimer direct la facture			
#			'result': {'type': 'print', 'report':'huissier.label.invoices', 'state':'end'}
		}
	}
wizard_close_dossier('huissier.dossier.close')


