{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ["base","account"],
	"update_xml" : [ "auction_view.xml", "auction_report.xml", "auction_wizard.xml"],
	"init_xml" : [ "auction_data.xml", "auction_demo.xml"],
}
