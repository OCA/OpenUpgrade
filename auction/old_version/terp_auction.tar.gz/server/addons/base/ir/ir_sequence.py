##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields,osv

class ir_sequence_type(osv.osv):
	_name = 'ir.sequence.type'
	_columns = {
		'name': fields.char('Sequence Name',size=64, required=True),
		'code': fields.char('Sequence Code',size=32, required=True),
	}
ir_sequence_type()

def _code_get(self, cr, user):
	cr.execute('select code, name from ir_sequence_type')
	return cr.fetchall()

class ir_sequence(osv.osv):
	_name = 'ir.sequence'
	_columns = {
		'name': fields.char('Sequence Name',size=64, required=True),
		'code': fields.selection(_code_get, 'Sequence Code',size=64, required=True),
		'active': fields.boolean('Active'),
		'prefix': fields.char('Prefix',size=8),
		'suffix': fields.char('Suffix',size=8),
		'number_next': fields.integer('Next Number', required=True),
		'number_increment': fields.integer('Increment Number', required=True),
	}
	_defaults = {
		'active': lambda x,y,z: True,
		'number_increment': lambda x,y,z: 1,
		'number_next': lambda x,y,z: 1,
	}
	#
	# TODO: should be thread safe !
	#
	def get(self, cr, uid, code):
		cr.execute('select id,number_next,number_increment,prefix,suffix from ir_sequence where code=%s and active=True', (code,))
		res = cr.fetchone()
		if res:
			cr.execute('update ir_sequence set number_next=number_next+number_increment where code=%s and active=True', (code,))
			final = (res[3] or '')+str(res[1])+(res[4] or '')
			return final
		return False
ir_sequence()

