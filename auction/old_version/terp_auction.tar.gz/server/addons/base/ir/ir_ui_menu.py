##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields,osv
from osv.orm import browse_null, browse_record

def one_in(setA, setB):
	"""Check the presence of an element of setA in setB
	"""
	for x in setA:
		if x in setB:
			return True
	return False

class ir_ui_menu(osv.osv):
	_name = 'ir.ui.menu'
	def _get_childs(self, cr, uid, ids, name, args, context):
		user_groups = self.pool.get('res.users').read(cr, 
												uid, [uid])[0]['groups_id']
		res = {}
		for menu_id in ids:
			res[menu_id] = [x[0] for x in self.getAllChilds(cr, menu_id) 
				   if (one_in(x[1],user_groups) or not x[1])] 
		return res

	def getAllChilds(self, cr, parent_id):
		"""returns the list of childs (id, groupsID) of parent_id
		"""
		sql = """
		select id, gid
		from ir_ui_menu as m left join menu_group_rel as g on m.id=g.menu_id
		where parent_id = %s
		""" % parent_id
		cr.execute(sql)
		childs = {}
		for child in cr.dictfetchall():
			if child['id'] in childs:
				if child['gid']:
					childs[child['id']].append(child['gid'])
			else:
				if child['gid']:
					childs[child['id']] = [child['gid']]
				else:
					childs[child['id']] = []
		return childs.items()

	def _get_full_name(self, cr, uid, ids, name, args, context):
 		res = {}
		for m in self.browse(cr, uid, ids):
			res[m.id] = self._get_one_full_name(m)
		return res

	def _get_one_full_name(self, menu):
		if menu.parent_id:
			parent_path = self._get_one_full_name(menu.parent_id) + "/"
		else:
			parent_path = ''
		return parent_path + menu.name
		
#	def unlink(*args):
#		raise osv.except_osv('Application Error!', "You can not remove a menu !")

	_columns = {
		'name': fields.char('Menu', size=64, required=True,
							translate=True),
		'child_id': fields.function(_get_childs,
									method=True,
									string='Childs'),
		'parent_id': fields.many2one('ir.ui.menu', 'Parent Menu'),
		'groups_id': fields.many2many('res.groups', 'menu_group_rel',
								   'menu_id', 'gid', 'Groups'),
		'complete_name': fields.function(_get_full_name, method=True, string='Complete Name', type='char', size=64),
	}

ir_ui_menu()
