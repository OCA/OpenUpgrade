##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields, osv

class ir_translation(osv.osv):
	_name = "ir.translation"
	_log_access = False
	_columns = {
		'name': fields.char('Name Field', size=128, required=True),
		'res_id': fields.integer('Ressource ID'),
		'lang':fields.char('Language',size=2),
		'src':fields.char('Source',size=255),
		'type':fields.char('Type',size=16),
		'value':fields.text('Translation Value'),
	}
	def _get_ids(self, cr, uid, name, tt, lang, ids):
		cr.execute('select res_id,value from ir_translation where lang=%s and type=%s and name=%s and res_id in ('+','.join(map(str,ids))+')', (lang,tt,name))
		return dict(cr.fetchall())

	def _set_ids(self, cr, uid, name, tt, lang, ids, value):
		cr.execute('delete from ir_translation where lang=%s and type=%s and name=%s and res_id in ('+map(str,ids)+')', (lang,tt,name))
		for id in ids:
			cr.execute('insert into ir_translation (lang,type,name,res_id,value) values (%s,%s,%s,%d,%s)', (lang,tt,name, id, value))
		return len(ids)

	def _get_source(self, cr, uid, name, tt, lang, source=None):
		if source:
			cr.execute('select value from ir_translation where lang=%s and type=%s and name=%s and src=%s', (lang, tt, str(name), source.strip().replace('\n',' ')))
		else:
			cr.execute('select value from ir_translation where lang=%s and type=%s and name=%s', (lang, tt, str(name)))
		res_trans = cr.fetchone()
		if res_trans:
			return res_trans[0]
		return False
ir_translation()
