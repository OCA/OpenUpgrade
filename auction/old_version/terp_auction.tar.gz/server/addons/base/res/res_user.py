##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields,osv

class groups(osv.osv):
	_name = "res.groups"
	_columns = {
		'name': fields.char('Group Name', size=64, required=True),
	}
groups()


class roles(osv.osv):
	_name = "res.roles"
	_columns = {
		'name': fields.char('Role Name', size=64, required=True),
		'parent_id': fields.many2one('res.roles', 'Parent'),
		'child_id': fields.one2many('res.roles', 'parent_id', 'Childs')
	}
roles()

class lang(osv.osv):
	_name = "res.lang"
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'code': fields.char('Code', size=5, required=True),
		'active': fields.boolean('Active'),
	}
	_defaults = {
		'active': lambda x,y,z: 1,
	}
lang()

class users(osv.osv):
	_name = "res.users"
	_log_access = False
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'login': fields.char('Login', size=64, required=True),
		'password': fields.char('Password', size=64, required=True, invisible=True),
		'signature': fields.text('Signature', size=64),
		'address_id': fields.many2one('res.partner.address', 'Address'),
		'action_id': fields.many2one('ir.actions.act_window', 'Action'),
		'groups_id': fields.many2many('res.groups', 'res_groups_users_rel', 'uid', 'gid', 'groups'),
		'roles_id': fields.many2many('res.roles', 'res_roles_users_rel', 'uid', 'rid', 'Roles'),
#		perm_default int references perm on delete set null,
	}
	def name_search(self, cr, user, name, args=[], operator='ilike', context={}):
		ids = self.search(cr, user, [('login','=',name)]+ args)
		if not ids:
			ids = self.search(cr, user, [('name',operator,name)]+ args)
		return self.name_get(cr, user, ids)
users()

