##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields
from osv import osv
import time

def _links_get(self, cr, uid):
	cr.execute('select object,name from res_request_link order by priority')
	return cr.fetchall()
	

#
# Model definition
#
class res_request(osv.osv):
	def request_process(self, cr, uid, ids, *args):
		for id in ids:
			cr.execute('update res_request set state=%s where id=%d', ('wait', id))
		return True

	def request_reply(self, cr, uid, ids, *args):
		for id in ids:
			cr.execute('select act_from,act_to,act_title as name, act_date,act_result from res_request where id=%d', (id,))
			values = cr.dictfetchone()
			values['req_id']=id
			values['act_date']=time.strftime('%Y-%m-%d')
			self.pool.get('res.request.history').create(cr, uid, values)
			cr.execute('update res_request set state=%s, act_from=act_to, act_to=act_from, act_title=\'\', act_date=NULL, act_result=\'\' where id=%d', ('active', id))
		return True

	def request_close(self, cr, uid, ids, *args):
		self.write(cr, uid, ids, {'state':'close', 'active':False})
		return True

	def request_get(self, cr, uid):
		cr.execute('select id from res_request where act_to=%d and (act_date<=%s or act_date is null) and active=True', (uid,time.strftime('%Y-%m-%d')))
		ids = map(lambda x:x[0], cr.fetchall())
		cr.execute('select id from res_request where act_from=%d and (act_to<>%d) and (act_date<=%s or act_date is null) and active=True', (uid,uid,time.strftime('%Y-%m-%d')))
		ids2 = map(lambda x:x[0], cr.fetchall())
		return (ids, ids2)

	_columns = {
		'name': fields.char('Request Description', states={'active':[('readonly',True)],'wait':[('readonly',True)]}, required=True, size=128),
		'active': fields.boolean('Active'),
		'req_ref': fields.char('Reference', states={'active':[('readonly',True)],'wait':[('readonly',True)]}, size=64),
		'req_type': fields.selection([('remind','Reminder'),('info','Information')], 'Request Type', states={'active':[('readonly',True)],'wait':[('readonly',True)]}, required=True),
		'req_priority': fields.selection([('0','very low'),('1','medium'),('2','urgent')], 'Priority', states={'active':[('readonly',True)],'wait':[('readonly',True)]}, required=True),
		'req_summary': fields.text('Request Summary', states={'active':[('readonly',True)],'wait':[('readonly',True)]}, required=True),
		'state': fields.selection([('draft','draft'),('wait','waiting'),('active','active'),('close','closed')], 'State', required=True, readonly=True),
		'act_from': fields.many2one('res.users', 'Request From', required=True, readonly=True),
		'act_to': fields.many2one('res.users', 'Request To', required=True, states={'wait':[('readonly',True)]}),
		'act_title': fields.char('Action Result', required=True, states={'wait':[('readonly',True)]}, size=128),
		'act_result': fields.text('Action Result Details', states={'wait':[('readonly',True)]}),
		'act_date': fields.date('Action Date', states={'wait':[('readonly',True)]}),
		'ref_partner_id':fields.many2one('res.partner', 'Partner Ref.'),
		'ref_doc1':fields.reference('Document Ref 1', selection=_links_get, size=128),
		'ref_doc2':fields.reference('Document Ref 2', selection=_links_get, size=128),
		'req_history': fields.one2many('res.request.history','req_id', 'Request History')
	}
	_defaults = {
		'act_from': lambda x,y,z: z,
		'state': lambda x,y,z: 'draft',
		'active': lambda x,y,z: 1,
		'req_priority': lambda x,y,z: 'medium',
		'req_type': lambda x,y,z: 'info'
	}
	_order = 'req_priority desc'
	_table = 'res_request'
	_name = 'res.request'
res_request()

class res_request_link(osv.osv):
	_columns = {
		'name': fields.char('Name', size=64, required=True),
		'object': fields.char('Link Object', size=64, required=True),
		'priority': fields.integer('Priority'),
	}
	_defaults = {
		'priority': lambda x,y,z: 5,
	}
	_order = 'priority'
	_name = 'res.request.link'
res_request_link()

class res_request_history(osv.osv):
	_columns = {
		'name': fields.char('Action Result', size=128, states={'active':[('readonly',True)],'wait':[('readonly',True)]}, required=True),
		'req_id': fields.many2one('res.request', 'Request', required=True),
		'act_from': fields.many2one('res.users', 'Request From', required=True, readonly=True),
		'act_to': fields.many2one('res.users', 'Request To', required=True, states={'wait':[('readonly',True)]}),
		'act_result': fields.text('Action Result Details', states={'wait':[('readonly',True)]}),
		'act_date': fields.date('Action Date', states={'wait':[('readonly',True)]}, required=True)
	}
	_name = 'res.request.history'
res_request_history()

