##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from email.MIMEText import MIMEText
import smtplib
import sql_db

import wizard
from osv.osv import osv_pools

email_send_form = '''<?xml version="1.0"?>
<form title="Mass Mailing">
	<field name="from"/>
	<newline/>
	<field name="subject"/>
	<newline/>
	<field name="text"/>
</form>'''

email_send_fields = {
	'from': {'string':'From', 'type':'char', 'size':64, 'required':True},
	'subject': {'string':'Subject', 'type':'char', 'size':64, 'required':True},
	'text': {'string':'Message', 'type':'text', 'required':True}
}

#FIXME: use tools/misc/sendmail instead
def sendmail(m_from, m_to, m_subject, m_msg):
	msg = MIMEText(m_msg)
	msg['Subject'] = m_subject
	msg['From'] = m_from
	msg['To'] = m_to
	s = smtplib.SMTP()
	s.connect()
#TODO: use logger instead of print 	
	print "sending email:", m_from, m_to, m_subject, m_msg
	s.sendmail(m_from, [m_to], msg.as_string())
	s.close()

def _mass_mail_send(self, uid, datas):
	cr = sql_db.db.cursor()
	nbr = 0
	for part in osv_pools.get('res.partner').browse(cr,uid,datas['ids']):
		for adr in part.address:
			if adr.email:
				name = adr.name or part.name
#				print "name:", name
				to = name + ' <' + adr.email + '>'
#				print "to:", to
#TODO:add some tests to check for invalid email address 
				sendmail(datas['form']['from'], to, datas['form']['subject'], datas['form']['text'])
				nbr += 1
#TODO: log number of message sent
	cr.close()
	return {'email_sent':nbr}

class part_email(wizard.interface):
	states = {
		'init': {
			'actions': [],
			'result': {'type': 'form', 'arch': email_send_form, 'fields': email_send_fields, 'state':[('send','Send Email'), ('end','Cancel')]}
		},
		'send': {
			'actions': [_mass_mail_send],
			'result': {'type': 'state', 'state':'end'}
		}
	}

part_email('res.partner.spam_send');


