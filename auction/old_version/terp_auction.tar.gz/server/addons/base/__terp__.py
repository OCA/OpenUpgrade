{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : [],
	"init_xml" : [
		"base_datas.xml",
		"res/project/project_demo.xml",
		"res/partner/partner_data.xml",
		"res/partner/partner_demo.xml",
		"res/partner/crm_demo.xml",
	],
	"update_xml" : [
		"base_update.xml",
		"ir/ir.xml",
		"res/project/project_view.xml",
		"res/res_request_view.xml",
		"res/partner/partner_report.xml",
		"res/partner/partner_view.xml",
		"res/partner/partner_wizard.xml",
		"res/partner/crm_view.xml",
	],
}
