{
	"name" : "Tiny TERP CRM",
	"version" : "1.0",
	"depends" : ["base", "account" ],
	"init_xml" : [ "crm_demo.xml" ],
	"update_xml" : [ "crm_view.xml", "crm_report.xml" ],
}
