{
	"name" : "Tiny TERP Campaign",
	"version" : "1.0",
	"depends" : ["base"],
	"update_xml" : [ "campaign/campaign_view.xml", "campaign/campaign_demo.xml", "campaign/campaign_wizard.xml" ],
	"init_xml" : [ ],
}
