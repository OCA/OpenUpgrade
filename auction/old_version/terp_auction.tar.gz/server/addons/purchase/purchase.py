##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

from osv import fields
from osv import osv
import time
import netsvc

import ir

#
# Model definition
#
class purchase_order(osv.osv):
	_columns = {
		'name': fields.char('Order Description', size=64, required=True),
		'ref': fields.char('Order Reference', size=64),
		'partner_ref': fields.char('Partner Reference', size=64),
		'purchase_rep': fields.char('Purchase Representative', size=64),
		'contact': fields.char('Partner Contact', size=64),
		'date_order':fields.date('Date Ordered', required=True, states={'confirmed':[('readonly',True)], 'approved':[('readonly',True)]}),
		'date_promise':fields.date('Date Promised'),
		'partner_id':fields.many2one('res.partner', 'Partner', required=True, states={'confirmed':[('readonly',True)], 'approved':[('readonly',True)]}),
		'partner_address_id':fields.many2one('res.partner.address', 'Address', required=True, states={'posted':[('readonly',True)]}),

		'warehouse_id': fields.many2one('stock.warehouse', 'Warehouse', required=True),
		'project_id':fields.many2one('res.project', 'Project', states={'posted':[('readonly',True)]}),

		'pricelist_id':fields.many2one('product.pricelist', 'Pricelist', required=True, states={'confirmed':[('readonly',True)], 'approved':[('readonly',True)]}),

		'state': fields.selection([('draft','draft'),('confirmed','confirmed'),('approved','approved'),('except_ship','Shipping Exception'),('except_invoice','Invoice Exception'),('done','done'),('cancel','cancel')], 'Order State', readonly=True),
		'order_line': fields.one2many('purchase.order.line', 'order_id', 'Order State', states={'confirmed':[('readonly',True)], 'approved':[('readonly',True)]}),
		'notes': fields.text('Notes'),
		'shipping_id': fields.many2one('stock.shipping', 'Shipping', readonly=True),
		'invoice_id': fields.many2one('account.invoice', 'Invoice', readonly=True),
		'shipped':fields.boolean('Shipped', readonly=True),
		'invoiced':fields.boolean('Invoiced', readonly=True)
	}
	_defaults = {
		'date_order': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'state': lambda x,y,z: 'draft',
		'shipped':  lambda x,y,z: 0,
		'invoiced':  lambda x,y,z: 0
	}
	_table = "purchase_order"
	_name = "purchase.order"

	def onchange_partner_id(self, cr, uid, ids, part):
		if not part:
			return {'value':{'partner_address_id': False}}
		addr = self.pool.get('res.partner').address_get(cr, uid, [part], ['contact'])
		pricelist=ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','product.pricelist.purchase'), ],[('id',str(part)),('uid',str(uid))])[0][2]
		return {'value':{'partner_address_id': addr['contact'], 'pricelist_id': pricelist}}

	# TODO: create invoice
	def init(self,cr):
		self._columns['warehouse_id'].selection = self.pool.get('stock.warehouse').name_search(cr,1)

	def action_invoice_create(self,cr, uid, ids, *args):
		res = False
		for o in self.browse(cr,uid,ids):
			il=[]
			for ol in o.order_line:
				opt=[('id',str(ol.product_id.id or -1)),('uid',str(uid))]
				a=ir.ir_get(cr,uid,[ ('meta','product.product'), ('name','account.expense')], opt)[0][2]
				il.append( (0,False,{'name':ol.name, 'account_id':a, 'price_unit':ol.price_unit, 'quantity':ol.quantity, 'invoice_line_tax_id':[x.id for x in ol.taxes_id] }) )

			opt=[('id',str(o.partner_id.id or -1)), ('uid',str(uid))]
			a=ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','account.payable')], opt)[0][2]
			inv={
				'name': o.name,
				'reference': "P%dPO%d"%(o.partner_id.id,o.id),
				'account_id': a,
				'type': 'in_invoice',
				'partner_id': o.partner_id.id,
				'address_invoice_id': o.partner_address_id.id,
				'address_contact_id': o.partner_address_id.id,
				'invoice_line': il,
			}
			inv_id = self.pool.get('account.invoice').create(cr, uid, inv)

			self.write(cr,uid,[o.id],{'invoice_id':inv_id})
			res = inv_id
		return res

	def action_shipping_create(self,cr, uid, ids, *args):
		orders = self.read(cr, uid, ids, ['order_line', 'partner_address_id','name','partner_id','warehouse_id'])
		ship_id = False
		for order in orders:
			ship_line = []
			lot_line = []
			order_lines = self.pool.get('purchase.order.line').read(cr, uid, order['order_line'])
			warehouse = self.pool.get('stock.warehouse').read(cr, uid, [order['warehouse_id'][0]], ['lot_input_id'])[0]

			for order_line in order_lines:
				lot_line.append( {'name': 'Receiving', 'product_id':order_line['product_id'][0], 'amount': order_line['quantity']} )
				ship_line.append( {'product_id':order_line['product_id'][0], 'amount': order_line['quantity']} )
			loc_id = ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','stock.lot.supplier')],[('id',str(order['partner_id'][0])),('uid',str(uid))])[0][2]
			lot = {'name': 'Purchasing lot', 'parent_id':loc_id, 'address_id': order['partner_address_id'][0], 'lot_line_id': map(lambda x: (0,0,x), lot_line)}
			lot_id = self.pool.get('stock.lot').create(cr, uid, lot)

			ship = {'name': 'Purchasing:'+order['name'][:50], 'partner_address_id':order['partner_address_id'][0], 'partner_id':order['partner_id'][0], 'lot_shipped_id': warehouse['lot_input_id'][0], 'shipping_line_id': map(lambda x: (0,0,x), ship_line), 'lot_stock_id': lot_id, 'type':'in'}
			ship['lot_output_id'] = loc_id

			ship_id = self.pool.get('stock.shipping').create(cr, uid, ship)
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'stock.shipping', ship_id, 'shipping_confirm', cr)

			self.write(cr, uid, [order['id']], {'shipping_id': ship_id})
		return ship_id
purchase_order()

class purchase_order_line(osv.osv):
	_columns = {
		'name': fields.char('Description', size=64, required=True),
		'quantity': fields.integer('Quantity', required=True),
		'date_promise': fields.date('Date Promised', required=True),
		'taxes_id': fields.many2many('account.tax', 'purchase_order_taxe', 'ord_id', 'tax_id', 'Taxes'),
		'product_id': fields.many2one('product.product', 'Product'),
		'price_unit': fields.float('Unit Price'),
		'notes': fields.text('Notes'),
		'order_id': fields.many2one('purchase.order', 'Order Ref')
	}
	_defaults = {
		'date_promise': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'quantity': lambda x,y,z: 1
	}
	_table = 'purchase_order_line'
	_name = 'purchase.order.line'
	def product_id_change(self, cr, uid, ids, pricelist, product, qty):
		if not pricelist:
			raise osv.except_osv('No Pricelist !', 'You have to select a pricelist in the sale form !\n Please set one before choosing a product.')
		if not product:
			return {'value': {'price_unit': 0.0, 'name':''}}
		price = self.pool.get('product.pricelist').price_get(cr,uid,[pricelist], product, qty or 1.0, 'standard')[pricelist]
		res = self.pool.get('product.product').read(cr, uid, [product], ['taxes_id','name'])[0]
		res = {'value': {'price_unit': price, 'name':res['name'], 'taxes_id':res['taxes_id']}}
		return res

purchase_order_line()

