{
	"name" : "Tiny TERP Purchase",
	"version" : "1.0",
	"depends" : ['base','account','stock'],
	"init_xml" : [ "purchase_workflow.xml", "purchase_data.xml"],
	"update_xml" : [ "purchase_view.xml", "purchase_report.xml"],
}
