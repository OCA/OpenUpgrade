##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import time
import netsvc
from osv import fields,osv,orm
import ir

class sale_shop(osv.osv):
	_name = "sale.shop"
	_columns = {
		'name': fields.char('Shop name',size=64, required=True),
		'payment_default_id':fields.many2one('account.account','Default payment',required=True),
		'payment_account_id':fields.many2many('account.account','sale_shop_account','shop_id','account_id','Account payments'),
		'warehouse_id':fields.many2one('stock.warehouse','Available Warehouse'),
		'pricelist_id':fields.many2one('product.pricelist', 'Pricelist'),
		'project_id':fields.many2one('res.project', 'Project'),
	}
sale_shop()

class sale_order(osv.osv):
	_name = "sale.order"
	def _amount_untaxed(self, cr, uid, ids, prop, unknow_none,unknow_dict):
		id_set=",".join(map(str,ids))
		cr.execute("SELECT s.id,COALESCE(SUM(l.price_unit*l.quantity),0) AS amount FROM sale_order s LEFT OUTER JOIN sale_order_line l ON (s.id=l.order_id) WHERE s.id IN ("+id_set+") GROUP BY s.id ")
		res=dict(cr.fetchall())
		return res

	def _amount_tax(self, cr, uid, ids, prop, unknow_none,unknow_dict):
		res={}
		for id in ids:
			val=0.0
			ol=self.read(cr,uid,[id],["order_line"])[0]
			for ol_id in ol["order_line"]:
				line=self.pool.get("sale.order.line").read(cr,uid,[ol_id],["tax_id","price_unit","quantity"])[0]
				for tax in line["tax_id"]:
					c = self.pool.get('account.tax').compute(cr, uid, [tax], line["price_unit"], line["quantity"])[0]
					val+=c['amount']
			res[id]=val
		return res

	def _amount_total(self, cr, uid, ids, prop, unknow_none,unknow_dict):
		res = {}
		untax = self._amount_untaxed(cr, uid, ids, prop, unknow_none,unknow_dict) 
		tax = self._amount_tax(cr, uid, ids, prop, unknow_none,unknow_dict)
		for id in ids:
			res[id] = untax.get(id,0) + tax.get(id,0)
		return res

	_columns = {
		'name': fields.char('Order Description',size=64, required=True),
		'shop_id':fields.many2one('sale.shop', 'Shop', required=True, readonly=True, states={'draft':[('readonly',False)]}),

		'state': fields.selection([
			('draft','Draft'),
			('manual','Manual in progress'),
			('progress','In progress'),
			('shipping_except','Shipping Exception'),
			('invoice_except','Invoice Exception'),
			('done','Done'),
			('cancel','Cancel')
		], 'Order State', readonly=True),

		'date_order':fields.date('Date Ordered', required=True, readonly=True, states={'draft':[('readonly',False)]}),
		'date_due':fields.date('Date Due Payment'),

		'partner_id':fields.many2one('res.partner', 'Partner', readonly=True, states={'draft':[('readonly',False)]}, change_default=True),
		'partner_contact_id':fields.many2one('res.partner.address', 'Contact Address', readonly=True, states={'draft':[('readonly',False)]}),
		'partner_invoice_id':fields.many2one('res.partner.address', 'Invoice Address', readonly=True, states={'draft':[('readonly',False)]}),
		'partner_shipping_id':fields.many2one('res.partner.address', 'Shipping Address', readonly=True, states={'draft':[('readonly',False)]}),

		'payment_term': fields.selection((('no','No'), ('month','2% 10 Net 30')), 'Payment Term'),
		'order_policy': fields.selection([
			('prepaid','Pay before delivery'),
			('manual','Shipping & Manual Invoice'),
			('postpaid','Invoice after delivery'),
		], 'Shipping Policy', required=True, readonly=True, states={'draft':[('readonly',False)]}),
		'pricelist_id':fields.many2one('product.pricelist', 'Pricelist', required=True, readonly=True, states={'draft':[('readonly',False)]}),
		'project_id':fields.many2one('res.project', 'Project', readonly=True, states={'draft':[('readonly',False)]}),

		'order_line': fields.one2many('sale.order.line', 'order_id', 'Order Lines', readonly=True, states={'draft':[('readonly',False)]}),
		'payment_line': fields.one2many('sale.order.payment', 'order_id', 'Order Payments', readonly=True, states={'draft':[('readonly',False)]}),

		'invoice_id': fields.many2one('account.invoice', 'Invoice', readonly=True),
		'shipping_id': fields.many2one('stock.shipping', 'Shipping', readonly=True),

		'shipping_created':fields.boolean('Shipping created', readonly=True),

		'shipped':fields.boolean('Shipped', readonly=True),
		'invoiced':fields.boolean('Paid', readonly=True),

		'note': fields.text('Notes'),

		'amount_untaxed': fields.function(_amount_untaxed, method=True, string='Untaxed Amount'),
		'amount_tax': fields.function(_amount_tax, method=True, string='Taxes'),
		'amount_total': fields.function(_amount_total, method=True, string='Total'),
	}
	_defaults = {
		'date_order': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'shipping_created': lambda x,y,z: 0,
		'date_promise': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'order_policy': lambda x,y,z: 'manual',
		'state': lambda x,y,z: 'draft'
	}

	# Form filling
	def onchange_shop_id(self, cr, uid, ids, shop_id):
		v={}
		if shop_id:
			shop=self.pool.get('sale.shop').browse(cr,uid,shop_id)
			v['project_id']=shop.project_id.id
			# Que faire si le client a une pricelist a lui ?
			if shop.pricelist_id.id:
				v['pricelist_id']=shop.pricelist_id.id
			v['payment_default_id']=shop.payment_default_id.id
		return {'value':v}

	def action_cancel_draft(self, cr, uid, ids, *args):
		self.write(cr, uid, ids, {'state':'draft'})
		wf_service = netsvc.LocalService("workflow")
		for inv_id in ids:
			wf_service.trg_create(uid, 'sale.order', inv_id, cr)
		return True

	def onchange_partner_id(self, cr, uid, ids, part):
		if not part:
			return {'value':{'partner_contact_id': False, 'partner_invoice_id': False, 'partner_shipping_id':False}}
		addr = self.pool.get('res.partner').address_get(cr, uid, [part], ['contact','delivery','invoice'])
		pricelist=ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','product.pricelist'), ],[('id',str(part)),('uid',str(uid))])[0][2]
		return {'value':{'partner_contact_id': addr['contact'], 'partner_invoice_id': addr['invoice'], 'partner_shipping_id':addr['delivery'], 'pricelist_id': pricelist}}

	def button_dummy(self, cr, uid, ids):
		self._log_event(cr, uid, ids, 'Draft Order')
		return True

	# Workflow
	def action_direct_sale(self, cr, uid, ids):
		for id in ids:
			o=self.browse(cr,uid,id)
			if len(o.payment_line)==0:
				pay={'order_id':o.id,'name':o.name+':Payment', 'account_id':o.shop_id.payment_default_id.id, 'amount':o.amount_total}
				self.pool.get('sale.order.payment').create(cr,uid,pay)
			invoice_id = self.action_invoice_create(cr,uid,ids)
			shipping_id = self.action_ship_create(cr,uid,ids)
			self.write(cr, uid, [id], {'shipping_id':shipping_id, 'invoice_id':invoice_id})
			o=self.browse(cr,uid,id)
			total=0.0
			for pay in o.payment_line:
				total+=pay.amount
				transfer={
					'name':pay.name,
					'partner_id': o.partner_id.id,
					'project_id': o.project_id.id,
					'type': 'in_payment',
					'reference': '',
					'account_src_id': o.invoice_id.account_id.id,
					'account_dest_id': pay.account_id.id,
					'amount': pay.amount,
					'invoice_id': [o.invoice_id.id],
				}
				t_id=self.pool.get('account.transfer').create(cr,uid,transfer)
				self.pool.get('account.transfer').pay_validate(cr,uid,[t_id])

			# Checker somme payment?
			# Make propertie of invoice==total
			# Checker stock?
			# Make propertie of shipping==possible
			if o.shipping_id:
				for pack in o.shipping_id.packing_id:
					wf_service = netsvc.LocalService("workflow")
					wf_service.trg_validate(uid, 'stock.packing', pack.id, 'packing_done', cr)
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'sale.order', o.id, 'pos_done', cr)
		return True

	def action_invoice_create(self, cr, uid, ids, *args):
		res = False
		for o in self.browse(cr,uid,ids):
			il=[]
			for ol in o.order_line:
				opt=[('id',str(ol.product_id.id or -1)),('uid',str(uid))]
				a=ir.ir_get(cr,uid,[ ('meta','product.product'), ('name','account.income')], opt)[0][2]
				il.append( (0,False,{'name':ol.name, 'account_id':a, 'price_unit':ol.price_unit, 'quantity':ol.quantity, 'invoice_line_tax_id':[x.id for x in ol.tax_id] }) )

			opt=[('id',str(o.partner_id.id or -1)), ('uid',str(uid))]
			a=ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','account.receivable')], opt)[0][2]
			inv={
				'name': o.name,
				'reference': "P%dSO%d"%(o.partner_id.id,o.id),
				'account_id': a,
				'partner_id': o.partner_id.id,
				'address_invoice_id': o.partner_invoice_id.id,
				'address_contact_id': o.partner_contact_id.id,
				'invoice_line': il,
			}
			inv_id = self.pool.get('account.invoice').create(cr, uid, inv)

			self.write(cr,uid,[o.id],{'invoice_id':inv_id,'state':'progress'})
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'account.invoice', inv_id, 'invoice_proforma', cr)
			res = inv_id
		return res

	def action_cancel(self, cr, uid, ids):
		for r in self.read(cr,uid,ids,['invoice_id','shipping_id']):
			if r['invoice_id']:
				wf_service = netsvc.LocalService("workflow")
				wf_service.trg_validate(uid, 'account.invoice', r['invoice_id'][0], 'invoice_cancel', cr)
			if r['shipping_id']:
				wf_service = netsvc.LocalService("workflow")
				wf_service.trg_validate(uid, 'account.invoice', r['shipping_id'][0], 'ship_cancel', cr)
		self.write(cr,uid,ids,{'state':'cancel','shipped':False,'invoiced':False,'invoice_id':False,'shipping_id':False})
		return True

	def action_wait(self, cr, uid, ids, *args):
		for r in self.read(cr,uid,ids,['order_policy','invoice_id']):
			if (r['order_policy']=='manual') and (not r['invoice_id']):
				self.write(cr,uid,[r['id']],{'state':'manual'})
			else:
				self.write(cr,uid,[r['id']],{'state':'progress'})

	def action_ship_create(self, cr, uid, ids, *args):
		for o in self.browse(cr,uid,ids):
			sl=[]
			for ol in o.order_line:
				if ol.product_id:
					sl.append((0,False,{'product_id':ol.product_id.id,'amount':ol.quantity }))
			ship={
				'name': o.name+":Deliver",
				'partner_id': o.partner_id.id,
				'serial': "P%dO%d"%(o.partner_id.id,o.id),
				'partner_address_id': o.partner_shipping_id.id,
				'warehouse_id': o.shop_id.warehouse_id.id,
				'shipping_line_id': sl,
			}
			ship.update(self.pool.get('stock.shipping').onchange_warehouse_id(cr, uid, [], ship['warehouse_id'])['value'])
			ship['lot_shipped_id'] = ir.ir_get(cr,uid,[ ('meta','res.partner'), ('name','stock.lot.customer')],[('id',str(o.partner_shipping_id.id)),('uid',str(uid))])[0][2]

			ship_id = self.pool.get('stock.shipping').create(cr, uid, ship)
			self.action_wait(cr,uid,[o.id])
			self.write(cr,uid,[o.id],{'shipping_id':ship_id})
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'stock.shipping', ship_id, 'shipping_confirm', cr)
			return ship_id
		return False

	def _log_event(self, cr, uid, ids, factor=0.7, name='Open Order'):
		invs = self.read(cr, uid, ids, ['date_order','partner_id','amount_untaxed'])
		for inv in invs:
			part=inv['partner_id'] and inv['partner_id'][0]
			pr = inv['amount_untaxed'] or 0.0
			partnertype = 'customer'
			eventtype = 'sale'
			self.pool.get('res.partner.event').create(cr, uid, {'name':'Order: '+name, 'som':False, 'description':'Order '+str(inv['id']), 'document':'', 'partner_id':part, 'date':time.strftime('%Y-%m-%d'), 'canal_id':False, 'user_id':uid, 'partner_type':partnertype, 'probability':1.0, 'planned_revenue':pr, 'planned_cost':0.0, 'type':eventtype})

	def has_stockable_products(self, cr, uid, ids, *args):
		id_set=",".join(map(str,ids))
		cr.execute("SELECT COUNT(*) AS c FROM sale_order_line WHERE product_id IS NOT NULL AND order_id IN ("+id_set+")")
		return cr.fetchone()[0]
sale_order()

class sale_order_line(osv.osv):
	_name = 'sale.order.line'
	_columns = {
		'order_id': fields.many2one('sale.order', 'Order Ref'),
		'name': fields.char('Description', size=64, required=True),
		'quantity': fields.integer('Quantity', required=True),
		'date_promise': fields.date('Date Promised'),
		'tax_id': fields.many2many('account.tax', 'sale_order_tax', 'order_line_id', 'tax_id', 'Taxes'),
		'product_id': fields.many2one('product.product', 'Product'),
		'price_unit': fields.float('Unit Price', required=True),
		'notes': fields.text('Notes'),
	}
	_defaults = {
		'date_promise': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'quantity': lambda x,y,z: 1,
		'price_unit': lambda x,y,z: 1,
	}
	def product_id_change(self, cr, uid, ids, pricelist, product, qty):
		if not pricelist:
			raise osv.except_osv('No Pricelist !', 'You have to select a pricelist in the sale form !\n Please set one before choosing a product.')
		if not product:
			return {'value': {'price_unit': 0.0, 'name':''}}
		price = self.pool.get('product.pricelist').price_get(cr,uid,[pricelist], product, qty or 1.0, 'list')[pricelist]
		if not price:
			raise osv.except_osv('Product not sellable !', 'You can not sell this product !\nYou have to change either the product, the qty or the pricelist.')
		res = self.pool.get('product.product').read(cr, uid, [product], ['taxes_id','name'])[0]
		return {'value': {'price_unit': price, 'name':res['name'], 'tax_id':res['taxes_id']}}
sale_order_line()

class sale_payment_line(osv.osv):
	_name = 'sale.order.payment'
	_columns = {
		'order_id': fields.many2one('sale.order', 'Order Ref'),
		'name': fields.char('Description', size=64, required=True),
		'account_id': fields.many2one('account.account', 'Account'),
		'amount': fields.float('Amount', required=True),
	}
	_defaults = {
	}
sale_payment_line()

