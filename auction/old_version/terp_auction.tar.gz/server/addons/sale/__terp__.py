{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ['product','stock'],
	"init_xml" : [  "sale_workflow.xml","sale_data.xml"],
	"update_xml" : [ "sale_view.xml", "sale_report.xml"],
}
