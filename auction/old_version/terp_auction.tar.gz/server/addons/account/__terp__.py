{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ["base"],
	"init_xml" : [ "account_workflow.xml", "account_data.xml", "datas/account_pcmn_belgium.xml", "account_demo.xml"],
	"update_xml" : [ "account_view.xml", "account_report.xml", "account_wizard.xml"],
}
