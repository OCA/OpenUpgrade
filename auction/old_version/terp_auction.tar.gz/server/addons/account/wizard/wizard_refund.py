##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import wizard
import netsvc
import time

def _invoice_refund(self, uid, datas, res_get=False):
	service = netsvc.LocalService("object_proxy")
#	invoice = service.execute(uid, 'account.invoice', 'read', [datas['id']])[0]
	invoice = service.execute(uid, 'account.invoice', 'read', [datas['id']], ['name', 'type', 'number', 'reference', 'project_id', 'comment', 'date_due', 'partner_id', 'address_contact_id', 'address_invoice_id', 'partner_contact', 'partner_insite', 'partner_ref', 'payment_term', 'account_id','invoice_line','tax_line'])[0]
		
	del invoice['id']
	
	if invoice['type']=='out_invoice':	# 'Customer Invoice'
		invoice['type']='out_refund'
	elif invoice['type']=='in_invoice': # 'Supplier Invoice'
		invoice['type']='in_refund'
	elif invoice['type']=='out_refund':	# 'Customer Refund'
		invoice['type']='out_invoice'
	elif invoice['type']=='in_refund':	# 'Supplier Refund'
		invoice['type']='in_invoice'
	
#CHECKME: what should I do with the date_due?
	invoice['date_invoice'] = time.strftime('%Y-%m-%d')
	invoice['state'] = 'draft'
	invoice['number'] = False
	
	for field in ('address_contact_id','address_invoice_id','partner_id','project_id','account_id'):
		invoice[field] = invoice[field] and invoice[field][0]

	line_ids = invoice['invoice_line']
	del invoice['invoice_line']
	
	tax_ids = invoice['tax_line']
	del invoice['tax_line']
		
	# create the new invoice
	invoice_id = service.execute(uid, 'account.invoice', 'create', invoice)
	
	# duplicate the invoice lines
	lines = service.execute(uid, 'account.invoice.line', 'read', line_ids)
	for line in lines:
		del line['id']
		line['invoice_id'] = invoice_id
		line['account_id'] = line['account_id'] and line['account_id'][0]
		service.execute(uid, 'account.invoice.line', 'create', line)

	# duplicate the tax lines (manual taxes only)
	tax_lines = service.execute(uid, 'account.invoice.tax', 'read', tax_ids)
	for line in tax_lines:
		if line['manual']:
			del line['id']
			line['invoice_id'] = invoice_id
			line['account_id'] = line['account_id'] and line['account_id'][0]
			service.execute(uid, 'account.invoice.tax', 'create', line)

	return {}

class wiz_refund(wizard.interface):
	states = {
		'init': {
			'actions': [_invoice_refund],
			'result': {'type': 'state', 'state':'end'}
		}
	}
wiz_refund('account.invoice.refund');

