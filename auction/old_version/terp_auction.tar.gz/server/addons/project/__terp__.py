{
 'name' : 'Tiny ERP Project Manager',
 'version': '0.1',
 'depends' : ['base','sale','account', 'hr'],
 'init_xml' : ['project_demo.xml'],
 'update_xml': ['project_view.xml','project_report.xml','project_wizard.xml'],
}
