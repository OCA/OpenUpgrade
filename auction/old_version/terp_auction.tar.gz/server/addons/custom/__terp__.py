{
	"name" : "Tiny TERP Customers specifications",
	"version" : "1.0",
	"depends" : ["base", "auction"],
	"init_xml" : [],
	"update_xml" : ["flagey/flagey_report.xml"],
	"active": True
}
