#!/usr/bin/python2.3
import time
import netsvc
from osv import fields,osv
import ir

#----------------------------------------------------------
# Stock Inventory
#----------------------------------------------------------
class stock_lot_inventory(osv.osv):
	_name = "stock.lot.inventory"
	_columns = {
		'name': fields.char('Inventory', size=64, required=True),
		'date': fields.datetime('Date create', required=True),
		'date_done': fields.datetime('Date done'),
		'state': fields.selection( (('draft','Draft'),('done','Done')), 'State', readonly=True),
		'users': fields.many2one('res.users', 'Utilisateur'),
		'inventory_line_id': fields.one2many('stock.lot.inventory.line', 'inventory_id', 'Inventories'),
		'lot_line_id': fields.one2many('stock.lot.line', 'lot_inventory_id', 'Inventories'),
	}
	_defaults = {
		'date': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
	}
	def action_done(self, cr, uid, ids, *args):
		for inv in self.browse(cr,uid,ids):
			# SUM(amount) GROUP BY lot_id,product_id
			move_line=[]
			for line in inv.inventory_line_id:
				pid=line.product_id.id
				# TODO good prive
				price=line.product_id.standard_price
				ll={ 'name': inv.name, 'lot_inventory_id': inv.id, 'lot_id': line.lot_id.id, 'product_id': pid, 'amount': line.amount }
				v=self.pool.get('stock.lot').product_get(cr, uid, [line.lot_id], [pid])
				old=v[pid]
				change=line.amount-old
				ainv=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_inventory')], [('id',str(pid)),('uid',str(uid))])[0][2]
				aexp=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_expense')], [('id',str(pid)),('uid',str(uid))])[0][2]
				ainc=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_income')], [('id',str(pid)),('uid',str(uid))])[0][2]
				if change:
					l1={'name':'Inv:'+line.product_id.name, 'account_id':ainv, 'amount':change*price }
					l2={'name':'Inv:'+line.product_id.name, 'account_id':ainc, 'amount':-change*price}
					if change<0:
						l2['account_id']=aexp
					move_line += [(0,0,l1), (0,0,l2)]
				self.pool.get('stock.lot.line').create(cr,uid,ll)
			move={'type': 'undefined', 'name': 'Inventory:'+inv.name, 'line_id': move_line}
			move_id=self.pool.get('account.move').create(cr, uid, move)
			self.write(cr, uid, [inv.id], {'state':'done', 'date_done': time.strftime('%Y-%m-%d %H:%M:%S')})
		return True
stock_lot_inventory()

#----------------------------------------------------------
# Lot
#----------------------------------------------------------
def stock_lot_product_id_get(cr, table, ids, name, arg, context={}):
	res = {}
	for id in ids:
		cr.execute('select product_id from stock_lot_line_view where lot_id=%d', (id,))
		res[id] = map(lambda x: x[0], cr.fetchall())
	return res


class stock_lot(osv.osv):
	def _cost_total(self, cr, uid, ids, prop, unknow_none,unknow_dict):
		cr.execute('SELECT lot_id, sum(amount*price_unit) AS amount FROM stock_lot_line where lot_id in ('+','.join(map(str,ids))+') group by lot_id')
		res = dict(cr.fetchall())
		for id in ids:
			if id not in res:
				res[id]=0.0
		return res

	_name = "stock.lot"
	_columns = {
		'name': fields.char('Lot', size=64, required=True),
		'active': fields.boolean('Active'),
		'type': fields.selection([('lot','lot'),('location','location')], 'Type'),
		'parent_id' : fields.many2one('stock.lot', 'Container'),
		'child_id': fields.one2many('stock.lot', 'parent_id', 'Contains'),
		'date': fields.datetime('Date create', required=True),
		'tracking': fields.char('Tracking', size=64),
		'serial': fields.char('Serial', size=64),
		'address_id': fields.many2one('res.partner.address', 'Address'),
		'lot_line_id': fields.one2many('stock.lot.line', 'lot_id', 'Movements'),
		'lot_line_view_id': fields.one2many('stock.lot.line.view', 'lot_id', 'Contents'),
		'product_id': fields.function(stock_lot_product_id_get, type='many2many', obj='product.product', string='Products', context="lot=id"),
		'price': fields.function(_cost_total, method=True, string='Total Costs Price' ),
		'move_history_lines': fields.one2many('stock.lot.move.history', 'lot_id', 'Move History')
	}
	_defaults = {
		'active': lambda x,y,z: 1,
		'type': lambda x,y,z: 'lot',
		'date': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
		'serial': lambda x,y,z: x.pool.get('ir.sequence').get(y,z,'stock.lot.serial'),
		'tracking': lambda x,y,z: x.pool.get('ir.sequence').get(y,z,'stock.lot.tracking'),
	}

	def account_usage_rec(self, cr, uid, id):
		cr.execute("SELECT usage FROM stock_location WHERE lot_id=%d",(id,))
		tmp=cr.fetchall()
		if len(tmp):
			return tmp[0][0]
		else:
			cr.execute("SELECT id FROM stock_lot WHERE parent_id=%d",(id,))
			tmp=cr.fetchall()
			if len(tmp):
				return self.account_usage(cr,uid,tmp[0][0])
		return False

	def account_usage(self, cr, uid, ids):
		res={}
		for id in ids:
			res[id]=self.account_usage_rec(cr,uid,id)
		return res

	def transitive_closure(self, cr, uid, ids, res={}, level=0):
		return self.search(cr,uid,[('parent_id','child_of',ids)])

	def product_get(self, cr, uid, ids, product_ids):
		lot_rec = self.transitive_closure(cr, uid, ids)
		lot_set = ",".join( map(str, lot_rec ) )
		prod_set = ",".join( map(str, product_ids) )
		cr.execute("SELECT product_id,SUM(amount) AS amount FROM stock_lot_line WHERE lot_id IN ("+lot_set+") AND product_id in ("+prod_set+") GROUP BY product_id")
		v=dict(cr.fetchall())
		for i in product_ids:
			v.setdefault(i,0)
		return v

	def product_get_amount_and_price(self, cr, uid, ids):
		""" 
		Takes a list of lot ids and compute the amount of each product in all these lots
		RETURNS: a dictionary of the form: {product_id:..., amount:..., name:..., price:...}
		         where price is the standard (unit) price for the product
		"""
		lot_rec = self.transitive_closure(cr, uid, ids)
		lot_set = ",".join( map(str, lot_rec) )
		#cr.execute("SELECT product_id, SUM(amount) AS amount, product_template.name AS name, product_template.standard_price AS price FROM stock_lot_line,product_product,product_template AS product WHERE product_template.id=product_tmpl_id AND product_product.id = product_id AND lot_id IN ("+lot_set+") GROUP BY product_id,product_template.name,product_template.standard_price")
		cr.execute("SELECT product_id, SUM(amount) AS amount FROM stock_lot_line WHERE lot_id IN ("+lot_set+") GROUP BY product_id")
		res = cr.dictfetchall()
		for r in res:
			cr.execute("SELECT name, variants, standard_price AS price FROM product_product, product_template WHERE product_template.id=product_tmpl_id AND product_product.id="+str(r['product_id']))
			r.update(cr.dictfetchone())
		
#		print "RES2: ", res
#		for r in res:
#			r.update({'lot_id':ids[0]})
#		res = [r.update({'lot_id':ids[0]}) for r in cr.dictfetchall()]
#		print "RES2: ", res
		return res #cr.dictfetchall()
		
	def product_get_amount_and_price_by_address(self, cr, uid, ids):
		""" 
		Takes a list of lot ids and compute the amount of each product in all these lots
		RETURNS: a dictionary of the form: {product_id:..., amount:..., name:..., price:...}
		         where price is the standard (unit) price for the product
		"""
		lot_rec = self.transitive_closure(cr, uid, ids)
		lot_set = ",".join( map(str, lot_rec) )
		#cr.execute("SELECT product_id, SUM(amount) AS amount, product_template.name AS name, product_template.standard_price AS price FROM stock_lot_line,product_product,product_template AS product WHERE product_template.id=product_tmpl_id AND product_product.id = product_id AND lot_id IN ("+lot_set+") GROUP BY product_id,product_template.name,product_template.standard_price")
		cr.execute("SELECT product_id, address_id AS address, SUM(amount) AS amount FROM (stock_lot_line LEFT JOIN stock_lot ON lot_id=stock_lot.id) WHERE lot_id IN ("+lot_set+") GROUP BY product_id,address_id")
		res = cr.dictfetchall()
#		print "RES1: ", res
		for r in res:
			cr.execute("SELECT name, variants, standard_price AS price FROM (product_product LEFT JOIN product_template ON product_template.id=product_tmpl_id) WHERE product_product.id="+str(r['product_id']))
			r.update(cr.dictfetchone())
		
#		print "RES2: ", res
#		for r in res:
#			r.update({'lot_id':ids[0]})
#		res = [r.update({'lot_id':ids[0]}) for r in cr.dictfetchall()]
#		print "RES2: ", res
		return res #cr.dictfetchall()
		
	def product_available_get_flat(self, cr, uid, ids, product_ids):
		lot_set = ",".join( map(str, ids ) )
		prod_set =" ,".join(map(str,product_ids))
		cr.execute("SELECT product_id,sum(amount) AS amount FROM ((SELECT product_id,SUM(amount) AS amount FROM stock_lot_line WHERE lot_id IN (%s) AND product_id IN (%s) GROUP BY product_id ) UNION ALL (SELECT product_id,-SUM(amount) AS amount FROM stock_packing sp left join stock_packing_line sl on (sp.id=sl.packing_id) WHERE sp.state='todo' and sl.lot_src_id IN (%s) AND sl.product_id IN (%s) AND sl.line_src_id IS NULL GROUP BY sl.product_id )) AS a GROUP BY product_id" % (lot_set,prod_set,lot_set,prod_set))
		v=dict(cr.fetchall())
		for i in product_ids:
			v.setdefault(i,0)
		return v

	def product_available_get(self, cr, uid, ids, product_ids):
		return self.product_available_get_flat(cr,uid, self.transitive_closure(cr, uid, ids), product_ids)

	def packing_allocate_flat(self, cr, uid, ids, prod_request, packing_id, force=False):
		lot_set = ",".join( map(str, ids ) )
		prod_set =" ,".join(map(str,list(prod_request)))
		cr.execute("SELECT product_id,lot_id,sum(amount) AS amount FROM ((SELECT product_id,lot_id,SUM(amount) AS amount FROM stock_lot_line WHERE lot_id IN (%s) AND product_id IN (%s) GROUP BY lot_id,product_id) UNION ALL (SELECT product_id,lot_src_id AS lot_id,-SUM(amount) AS amount FROM stock_packing sp left join stock_packing_line sl on (sp.id=sl.packing_id) WHERE sp.state='todo' and sl.lot_src_id IN (%s) AND sl.product_id IN (%s) AND sl.line_src_id IS NULL GROUP BY sl.lot_src_id,sl.product_id )) AS a GROUP BY lot_id,product_id ORDER BY product_id,amount" % (lot_set,prod_set,lot_set,prod_set))
		lot = {}
		for (prod_id,lot_id,amount) in cr.fetchall():
			if lot.has_key(prod_id):
				lot[prod_id].append((lot_id,amount))
			else:
				lot[prod_id]=[(lot_id,amount)]
		unsat = {}
		for (prod_id,need) in prod_request.items():
			for (lot_id,avail) in lot.get(prod_id,[]):
				sat = avail>need
				alloc = min(need,avail)
				need -= alloc
				if alloc>0:
					pl = {'name':'pack', 'packing_id':packing_id, 'lot_src_id':lot_id, 'product_id':prod_id, 'amount':alloc }
					self.pool.get('stock.packing.line').create(cr, uid, pl)
				if sat:
					break
			if not sat:
				unsat[prod_id]=need
		return unsat

	def packing_allocate(self, cr, uid, ids, prod_request, packing_id, force=False):
		return self.packing_allocate_flat(cr,uid, self.transitive_closure(cr, uid, ids), prod_request,packing_id)
stock_lot()

class stock_lot_line(osv.osv):
	_name = "stock.lot.line"
	_columns = {
		'name': fields.char('Lot Inventory Line', size=64, required=True),
		'active': fields.boolean('Active'),
		'date':fields.datetime('Date create', required=True),
		'lot_inventory_id': fields.many2one('stock.lot.inventory','Inventory'),
		'lot_id': fields.many2one('stock.lot','Lot'),
		'product_id': fields.many2one('product.product', 'Product', required=True ),
		'amount': fields.float('Amount'),
		'price_unit': fields.float('Unit Costs Price', digits=(16,2) )
	}
	_defaults = {
		'active': lambda x,y,z: 1,
		'date': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
	}
	def _check_inventory(self, cr, uid, ids):
		res = self.read(cr, uid, ids, ['active','date','lot_inventory_id','lot_id'])
		res.reverse()
		for r in res:
			if r['active'] and r['lot_inventory_id']:
				cr.execute('update stock_lot_line set active=False where date<%s and lot_id=%d', (r['date'],r['lot_id'][0]))
				return True
		return False
	def create(self, cr, uid, args):
		id = osv.osv.create(self,cr, uid, args)
		self._check_inventory(cr, uid, [id])
		return id
	def write(self, cr, uid, ids, args):
		res = osv.osv.write(self,cr, uid, ids, args)
		self._check_inventory(cr, uid, ids)
		return res
stock_lot_line()

class stock_lot_line_view(osv.osv):
	_name = "stock.lot.line.view"
	_auto = False
	_table = "stock_lot_line_view"
	_auto = False
	_columns = {
		'name': fields.char('Lot Content', size=64),
		'product_id': fields.many2one('product.product', 'Product'),
		'lot_id':fields.many2one('stock.lot','Lot'),
		'amount': fields.float( 'Quantity'),
	}
	def init(self, cr):
		cr.execute("CREATE OR REPLACE VIEW stock_lot_line_view AS SELECT MIN(id) AS id, lot_id::VARCHAR AS name,lot_id,product_id,SUM(amount) AS amount FROM stock_lot_line WHERE active=true GROUP BY lot_id,product_id")
		cr.commit()
stock_lot_line_view()

#----------------------------------------------------------
# Stock Inventory Line
#----------------------------------------------------------

class stock_lot_inventory_line(osv.osv):
	_name = "stock.lot.inventory.line"
	_columns = {
		'inventory_id': fields.many2one('stock.lot.inventory','Inventory'),
		'lot_id': fields.many2one('stock.lot','Lot'),
		'product_id': fields.many2one('product.product', 'Product', required=True ),
		'amount': fields.float('Amount'),
	}
stock_lot_inventory_line()

#----------------------------------------------------------
# Stock Location
#----------------------------------------------------------
class stock_location(osv.osv):
	_name = "stock.location"
	_inherits = {'stock.lot': 'lot_id'}
	_columns = {
		'active': fields.boolean('Active'),
		'usage': fields.selection([('supplier','supplier'),('internal','internal'),('customer','customer')], 'Usage'),
		'lot_id': fields.many2one('stock.lot', string='Lot'),
		'account_id': fields.many2one('account.account', string='Inventory Account', domain=[('type','=','inventory')]),
		'location_child_id': fields.one2many('stock.location', 'parent_id', 'Contains'),
		'comment': fields.text('Additionnal Information'),
		'posx': fields.integer('Position X', required=True),
		'posy': fields.integer('Position Y', required=True),
		'posz': fields.integer('Position Z', required=True)
	}
	_defaults = {
		'active': lambda x,y,z: 1,
		'type': lambda x,y,z: 'location',
		'usage': lambda x,y,z: 'internal',
		'posx': lambda x,y,z: 0,
		'posy': lambda x,y,z: 0,
		'posz': lambda x,y,z: 0,
	}

	def transitive_closure(self, cr, uid, ids, res={}, level=0):
		return self.search(cr,uid,[('parent_id','child_of',ids)])

#	def packing_allocate(self, cr, uid, ids, prod_request, packing_id, force=False):
#		loc_set=",".join(map(str,self.transitive_closure(cr,uid,ids)))
#		cr.execute("SELECT id,(posx-0)+(posy-0)+(posz-0) AS dist FROM stock_location WHERE id IN (%s) ORDER BY dist"%loc_set)
#		loc_ids = map(lambda x: x[0], cr.fetchall())
#		unsat = prod_request
#		print 'location ',ids,' trying to sat ',prod_request,' with ',loc_ids
#		for loc_id in loc_ids:
#			cr.execute("SELECT id FROM stock_lot WHERE location_id=%d"%loc_id)
#			lot_ids = map(lambda x: x[0], cr.fetchall())
#			if len(lot_ids):
#				unsat = self.pool.get('stock.lot').packing_allocate(cr, uid, lot_ids, unsat, packing_id)
#			if len(unsat)==0:
#				break
#		print "Location alloacate done unsat=",unsat
#		return unsat
stock_location()

#----------------------------------------------------------
# Stock Move
#----------------------------------------------------------
class stock_move(osv.osv):
	_name = "stock.move"
	_columns = {
		'name': fields.char('Movement Description', size=64, required=True),
		'active': fields.boolean('Active'),
		'state': fields.selection( (('draft','Draft'),('done','Moved')), 'State', readonly=True),
		'serial': fields.char('Tracking Number', size=32),
		'date_planned': fields.date('Planned Date'),
		'date_moved': fields.date('Actual Date'),
		'lot_id': fields.many2one('stock.lot','Lot', required=True),
		'lot_dest_id': fields.many2one('stock.location', 'Destination Lot', required=True),
		'address_id': fields.many2one('res.partner.address', 'Destination Address'),
	}
	_defaults = {
		'active': lambda x,y,z: 1,
		'state': lambda x,y,z: 'draft',
		'date_planned': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
	}
	def action_move(self, cr, uid, ids):
		for move in self.read(cr, uid, ids):
			lot=self.pool.get('stock.lot').browse(cr,uid,move['lot_id'][0])
			if lot.parent_id:
				src=lot.parent_id.id
				dest=move['lot_dest_id'][0]
				v=self.pool.get('stock.lot').account_usage(cr,uid,[src,dest])
				src_usage=v[src]
				dest_usage=v[dest]
				if src_usage=='internal' and dest_usage=='customer':
					move_line=[]
					for line in lot.lot_line_id:
						pid=line.product_id.id
						# TODO good prive
						price=line.product_id.product_tmpl_id.standard_price
						ainv=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_inventory')], [('id',str(pid)),('uid',str(uid))])[0][2]
						aexp=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_expense')], [('id',str(pid)),('uid',str(uid))])[0][2]
						ainc=ir.ir_get(cr,uid,[('meta','product.product'), ('name','account.stock_income')], [('id',str(pid)),('uid',str(uid))])[0][2]
						l1={'name':'Move:'+line.product_id.name, 'account_id':ainv, 'amount':-line.amount*price }
						l2={'name':'Move:'+line.product_id.name, 'account_id':aexp, 'amount':line.amount*price}
						move_line += [(0,0,l1), (0,0,l2)]
					mv={'type': 'undefined', 'name': 'Move:'+move['name'], 'line_id': move_line}
					move_id=self.pool.get('account.move').create(cr, uid, mv)
			adr=move['address_id'] and move['address_id'][0]
			ldest=move['lot_dest_id'][0]
			self.pool.get('stock.lot.move.history').create(cr, uid, {'lot_id': lot.id,'name':lot.name, 'location_id':lot.parent_id, 'address_id':adr })
			self.pool.get('stock.lot').write(cr, uid, [move['lot_id'][0]], {'parent_id': ldest ,'address_id':adr })
		return self.write(cr, uid, ids, {'state':'done', 'date_moved': time.strftime('%Y-%m-%d')})
stock_move()

class stock_lot_move_history(osv.osv):
	_name = "stock.lot.move.history"
	_columns = {
		'name': fields.char('Lot', size=64, required=True),
		'lot_id' : fields.many2one('stock.lot', 'Container'),
		'location_id' : fields.many2one('stock.lot', 'Container'),
		'address_id' : fields.many2one('res.partner.address', 'Address'),
		'date': fields.datetime('Date create', required=True),
	}
	_defaults = {
		'date': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
	}
stock_lot_move_history()


#----------------------------------------------------------
# Stock Packing
#----------------------------------------------------------
class stock_packing(osv.osv):
	_name = "stock.packing"
	_columns = {
		'name': fields.char('Packing Name', size=64, required=True),
		'type': fields.selection([('out','Sending Goods'),('in','Getting Goods'),('internal','Internal')], 'Shipping Type'),
		'active': fields.boolean('Active'),
		'state': fields.selection([
			('draft','draft'),
			('todo','todo'),
			('done','done'),
			('cancel','cancel'),
			], 'State'),
		'date':fields.datetime('Date create'),
		'lot_pack_id': fields.many2one('stock.lot', 'Pack Lot'),
		'lot_pack_parent_id': fields.many2one('stock.lot', 'Pack Container'),
		'lot_dest_parent_id': fields.many2one('stock.lot', 'Shipping Lot',required=True),
		'address_id': fields.many2one('res.partner.address', 'Shipping Address'),
		'packing_line_id': fields.one2many('stock.packing.line','packing_id', 'Packing Line', required=True),
		'move_id': fields.many2one('stock.move', 'Move Order'),
	}
	_defaults = {
		'active': lambda x,y,z: 1,
		'state': lambda x,y,z: 'draft',
		'date': lambda x,y,z: time.strftime('%Y-%m-%d %H:%M:%S'),
	}
	def packing_todo(self, cr, uid, ids, *args):
		self.write(cr,uid,ids, {'state':'todo'})
		return True

	def packing_cancel(self, cr, uid, ids, *args):
		self.write(cr,uid,ids, {'state':'cancel', 'date':False})
		return True

	def packing_done(self, cr, uid, ids, *args):
		for pack in self.read(cr,uid,ids):
			line_ids=pack['packing_line_id']
			if pack['lot_pack_id']:
				lot_pack=pack['lot_pack_id'][0]
			else:
				if pack['lot_pack_parent_id']:
					pack_parent=pack['lot_pack_parent_id'][0]
				else:
					pack_parent=False
				lot_pack=self.pool.get('stock.lot').create(cr,uid,{'name':'Packed','parent_id':pack_parent})
				self.write(cr,uid, [pack['id']], {'lot_pack_id':lot_pack})
			for r in self.pool.get('stock.packing.line').read(cr, uid, line_ids, ['lot_src_id','amount','product_id']):
				id1 = self.pool.get('stock.lot.line').create(cr, uid, {'product_id':r['product_id'][0], 'lot_id':r['lot_src_id'][0], 'amount':-r['amount'], 'name': 'move'})
				id2 = self.pool.get('stock.lot.line').create(cr, uid, {'product_id':r['product_id'][0], 'lot_id':lot_pack, 'amount':r['amount'], 'name': 'move'})
				self.pool.get('stock.packing.line').write(cr, uid, [r['id']], {'line_src_id':id1, 'line_dest_id':id2,  'active':1})
			self.write(cr, uid, [pack['id']], {'state':'done', 'active':1, 'date':time.strftime('%Y-%m-%d %H:%M:%S') })
		return True

	def packing_ship(self, cr, uid, ids, *args):
		for pack in self.read(cr,uid,ids):
			if not pack['move_id']:
				dp=pack['lot_dest_parent_id'][0]
				adr=pack['address_id'] and pack['address_id'][0]
				move_id=self.pool.get('stock.move').create(cr,uid,{'name':pack['name']+':Move', 'lot_id':pack['lot_pack_id'][0], 'lot_dest_id':dp, 'address_id':adr})
				self.write(cr, uid, [pack['id']], {'move_id':move_id, })
				self.pool.get('stock.move').action_move(cr, uid, [move_id])
		return True

	def action_done_cancel(self, cr, uid, ids, *args):
		for pack in self.read(cr,uid,ids):
			ll = []
			for r in self.pool.get('stock.packing.line').read(cr, uid, pack['packing_line_id'], ['line_src_id', 'line_dest_id']):
				ll.append(r['line_src_id'][0])
				ll.append(r['line_dest_id'][0])
			self.pool.get('stock.lot.line').unlink(cr, uid, ll)
			if pack['move_id']:
				self.pool.get('stock.move').unlink(cr, uid, [pack['move_id'][0]])
			self.write(cr, uid, ids, {'state':'cancel','date':False})
		# delete empty packing ?
		return True

	def action_cancel_draft(self, cr, uid, ids, *args):
		self.write(cr, uid, ids, {'state':'draft'})
		wf_service = netsvc.LocalService("workflow")
		for inv_id in ids:
			wf_service.trg_create(uid, 'stock.packing', inv_id, cr)
		return True
stock_packing()

class stock_lot_packing_line(osv.osv):
	_name = "stock.packing.line"
	_columns = {
		# Unused name
		'name': fields.char('Name', size=64, required=True),
		'active': fields.boolean('Active'),
		'packing_id': fields.many2one('stock.packing', 'Packing', required=True),
		'lot_src_id': fields.many2one('stock.lot','Lot Src'),
		'product_id': fields.many2one('product.product', 'Product', required=True, context="lot=lot_src_id"),
		'amount': fields.float('Amount'),
		'line_src_id': fields.many2one('stock.lot.line','Lot Line Src'),
		'line_dest_id': fields.many2one('stock.lot.line', 'Lot Line Dest'),
	}
	_defaults = {
		'active': lambda x,y,z: 1,
	}
stock_lot_packing_line()

#----------------------------------------------------------
# Stock Warehouse
#----------------------------------------------------------
class stock_warehouse(osv.osv):
	_name = "stock.warehouse"
	_columns = {
		'name': fields.char('Name', size=60, required=True),
#		'partner_id': fields.many2one('res.partner', 'Owner'),
#		'partner_address_id': fields.many2one('res.partner.address', 'Owner Address'),
		'lot_input_id': fields.many2one('stock.lot', 'Location Input' ),
		'lot_stock_id': fields.many2one('stock.lot', 'Location Stock' ),
		'lot_output_id': fields.many2one('stock.lot', 'Location Output' ),
	}
stock_warehouse()

#----------------------------------------------------------
# Stock Shipping
#----------------------------------------------------------
class stock_shipping(osv.osv):
	_name = "stock.shipping"
	_columns = {
		'name': fields.char('Name', size=60, required=True),
		'active': fields.boolean('Active'),

		'type': fields.selection([('out','Sending Goods'),('in','Getting Goods'),('internal','Internal')], 'Shipping Type'),
		'priority': fields.selection([('0','Very Urgent'),('1','Urgent'),('2','Normal'),('3','Not urgent')], 'priority'),
		'serial': fields.char('Serial', size=64),
		'date_creation': fields.date('Date Creation'),
		'date_promised': fields.date('Date Promised'),

		'packing_policy': fields.selection([('direct','Direct Packing'),('per product','Per Product Packing'),('total','One Packing')], 'Packaging Policy' ),
		'shipping_policy': fields.selection([('direct','Direct Delivery'),('total','All at once')], 'Shipping Policy' ),

		'partner_id': fields.many2one('res.partner', 'Partner'),
		'partner_address_id': fields.many2one('res.partner.address','Address'),

		'state': fields.selection([('draft','draft'),('progress','Waiting Goods'),('packed','Waiting Picking'),('done','Done'),('exception','Exception'),('cancel','Cancel')],'State', required=True),

		'shipping_line_id': fields.one2many('stock.shipping.line', 'shipping_id', 'Shipping Lines'),

		'packing_id': fields.many2many('stock.packing', 'stock_shipping_packing_rel', 'shipping_id', 'packing_id', 'Packings'),

		'warehouse_id': fields.many2one('stock.warehouse', 'Warehouse'),
		'lot_stock_id': fields.many2one('stock.lot', 'Source Lot/Location',required=True),
		'lot_output_id': fields.many2one('stock.lot', 'Intermediary Location',required=True),
		'lot_shipped_id': fields.many2one('stock.lot', 'Destination Location',required=True),
	}
	_defaults = {
		'date_creation': lambda x,y,z: time.strftime('%Y-%m-%d'),
		'active': lambda x,y,z: 1,
		'state': lambda x,y,z: 'draft',
		'type': lambda x,y,z: 'out',
		'packing_policy': lambda x,y,z: 'direct',
		'shipping_policy': lambda x,y,z: 'direct',
		'priority': lambda x,y,z: 2,
	}

	def onchange_warehouse_id(self, cr, uid, ids, w):
		if w:
			wh=self.pool.get('stock.warehouse').read(cr,uid,[w])[0]
			return {'value':{ 'lot_stock_id': wh['lot_stock_id'][0], 'lot_output_id': wh['lot_output_id'][0]} }
		else:
			return {'value':{}}

	def _packing_todo_get(self, cr, uid, id, states=[]):
		whstate = ''
		if len(states):
			whstate = ' and (p.state in ('+','.join(map(lambda x:"'%s'" % (x,), states))+'))'
		cr.execute('select product_id,sum(amount) from stock_packing_line where packing_id in (select p.id from stock_packing p left join stock_shipping_packing_rel r on (p.id=r.packing_id) where r.shipping_id=%d'+whstate+') group by product_id', (id,))
		processed = dict(cr.fetchall())
		cr.execute("SELECT product_id,SUM(amount) AS amount FROM stock_shipping_line WHERE shipping_id=%d GROUP BY product_id", (id,))
		request = dict(cr.fetchall())
		todo = {}
		for r in request:
			if request[r]-processed.get(r, 0.0):
				todo[r] = request[r]-processed.get(r, 0.0)
		return todo

	def _packing_ship(self, cr, uid, ids):
		id_set=",".join(map(str,ids))
		cr.execute("SELECT p.id FROM stock_packing p WHERE p.state='done' AND id in (SELECT packing_id FROM stock_shipping_packing_rel WHERE shipping_id IN (%s))"%id_set)
		return self.pool.get('stock.packing').packing_ship(cr,uid,map(lambda x: x[0], cr.fetchall()))

	def ship_cancel(self, cr, uid, ids, *args):
		id_set=",".join(map(str,ids))
		cr.execute("SELECT p.id FROM stock_packing p WHERE p.state='todo' AND id in (SELECT packing_id FROM stock_shipping_packing_rel WHERE shipping_id IN (%s))"%id_set)
		for (packing_id,) in cr.fetchall():
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'stock.packing', packing_id, 'packing_cancel', cr)
		return self.write(cr, uid, ids, {'state':'cancel'})

	def ship_exception(self, cr, uid, ids, *args):
		return self.write(cr, uid, ids, {'state':'exception'})

	def packing_ship(self, cr, uid, ids, *args):
		for res in self.read(cr,uid,ids,['shipping_policy']):
			id=res['id']
			if res['shipping_policy']=='direct':
				self._packing_ship(cr,uid,[id])
		return True

	def packing_done(self, cr, uid, ids, *args):
		self._packing_ship(cr,uid,ids)
		self.write(cr, uid, ids, {'state':'done'})
		return True

	# Check if everything is packed !
	def packing_done_check_done(self, cr, uid, ids, *args):
		for ship_id in ids:
			todo = self._packing_todo_get(cr, uid, ship_id, ['done'])
			if not todo:
				return True
			sum = reduce(lambda x,y: x+y, todo.values())
			if sum>0:
				return False
		return True

	# Check if everything is packed !
	def packing_done_check(self, cr, uid, ids, *args):
		for ship_id in ids:
			todo = self._packing_todo_get(cr, uid, ship_id, ['todo','done'])
			if not todo:
				return True
			sum = reduce(lambda x,y: x+y, todo.values())
			if sum>0:
				return False
		return True

	# TODO: improve check packing method
	def packing_create_check(self, cr, uid, ids, *args):
		packing_id=None
		for ship_id in ids:
			todo = self._packing_todo_get(cr, uid, ship_id, ['todo','done'])
			ship=self.read(cr,uid,[ship_id])[0]
			products = self.pool.get('stock.lot').product_available_get(cr, uid, [ship['lot_stock_id'][0]], todo.keys())
			sum = reduce(lambda x,y: x+y, products.values())
			sum2 = reduce(lambda x,y: x+y, todo.values())
			if sum<=0:
				return False
			if ship['packing_policy']=='total' and (sum2>sum):
				return False
		return True

	def packing_create(self, cr, uid, ids, *args):
		# Method ALL OR NOTHING
		packing_id=None
		for ship_id in ids:
			ship=self.read(cr,uid,[ship_id])[0]
			lstock=ship['lot_stock_id'][0]
			lout=ship['lot_output_id'][0]
			lship=ship['lot_shipped_id'][0]
			adr=ship['partner_address_id'] and ship['partner_address_id'][0]
			packing_id=self.pool.get('stock.packing').create(cr,uid,
			{'name':ship['name']+':Pack', 'lot_pack_parent_id':lout, 'lot_dest_parent_id':lship,'address_id':adr, 'type':ship['type']})
			request = self._packing_todo_get(cr, uid, ship_id, ['todo','done'])
			unsat=self.pool.get('stock.lot').packing_allocate(cr, uid, [lstock], request, packing_id)
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, 'stock.packing', packing_id, 'packing_todo', cr)
			self.write(cr,uid,[ship_id], {'state':'progress', 'packing_id':ship['packing_id']+[packing_id]})
		return packing_id
stock_shipping()

class stock_shipping_line(osv.osv):
	_name = "stock.shipping.line"
	_columns = {
		'shipping_id': fields.many2one('stock.shipping','Shipping'),
		'product_id': fields.many2one('product.product', string='Product'),
		'amount': fields.float('Amount')
	}
	_rec_name = 'product_id'
stock_shipping_line()

