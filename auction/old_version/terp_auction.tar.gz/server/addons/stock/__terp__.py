{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ['product','account'],
	"init_xml" : [ "stock_workflow.xml", "stock_data.xml"],
	"update_xml" : [ "stock_view.xml", "stock_report.xml" ],
}
