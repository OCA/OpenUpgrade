##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be)
#
# $Id: __init__.py 908 2005-07-08 07:51:38Z nicoe $
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contact a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import os, sys, imp

import tools

import netsvc
logger = netsvc.Logger()

opj = os.path.join
ad = tools.config['addons_path']
sys.path.insert(1,ad)

# create the list of modules to load

loaded={}
unloaded={}
init={}
update={}
active={}
for i in os.listdir(ad):
	if os.path.isfile(opj(ad, i, "__terp__.py")):
		info = eval(file(opj(ad, i, "__terp__.py")).read())
		if info.get('active', True):
			unloaded[i] = info['depends']
			init[i] = info.get('init_xml', [])
			update[i] = info.get('update_xml', [])
		active[i]=info.get('active',True)

while len(unloaded):
	for (m,dep) in unloaded.items():
		ready = True
		for j in dep:
			if not (j in loaded or j in unloaded):
				logger.notifyChannel("init", netsvc.LOG_ERROR, "addon:%s:couldn't load module because of unmet dependency (%s) !" % (m,j))
				del unloaded[m]
			ready = ready and j in loaded
		if not active[m]:
			del unloaded[m]
			continue
		if ready:
			logger.notifyChannel("init", netsvc.LOG_INFO, 'addon:%s' % (m,))
			sys.stdout.flush()
			imp.load_module(m, *imp.find_module(m))
			idref = {}
			if tools.config["init"].has_key(m) or tools.config["init"].has_key("all"):
				for xml in init.get(m,[]):
					logger.notifyChannel("init", netsvc.LOG_INFO, 'addon:%s:init %s' % (m,xml))
					tools.convert_xml_import(tools.file_open(opj(m,xml)).read(), idref)
				for xml in update.get(m,[]):
					logger.notifyChannel("init", netsvc.LOG_INFO, 'addon:%s:init %s' % (m,xml))
					tools.convert_xml_import(tools.file_open(opj(m,xml)).read(), idref)
			elif tools.config["update"].has_key(m) or tools.config["update"].has_key("all"):
				for xml in update.get(m,[]):
					logger.notifyChannel("init", netsvc.LOG_INFO, 'addon:%s:update %s' % (m,xml))
					tools.convert_xml_import(tools.file_open(opj(m,xml)).read(), idref)
			del unloaded[m]
			loaded[m] = 1


