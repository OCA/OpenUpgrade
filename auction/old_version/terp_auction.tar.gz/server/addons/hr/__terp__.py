{
 "name" : "Tiny ERP Human Ressources Management",
 "version" : "0.1",
 "depends" : ["base"],
 "init_xml" : ['hr_init.xml', 'hr_workflow.xml', 'hr_bel_holidays_2005.xml'],
 "update_xml" : ['hr_view.xml', 'hr_report.xml', 'hr_wizard.xml'],
}
