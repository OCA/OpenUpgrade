{
	"name" : "Tiny TERP Accounting",
	"version" : "1.0",
	"depends" : ['base'],
	"init_xml" : ['subscription_data.xml' ],
	"update_xml" : ['subscription_view.xml'],
}
