import sql_db
import netsvc
import pickle

def ir_set(cr, uid, keys, args, name, value, replace=True, isobject=False, meta=None):
	parent = None
	for (key,val) in keys+args:
		if parent:
			where = ' and parent_id=%d' % (parent,)
		else:
			where = ' and parent_id is null'
		cr.execute('select id from ir_values_keys where key=%s and value=%s'+where, (key,val))
		res = cr.fetchone()
		if not res:
			cr.execute("select nextval('ir_values_keys_id_seq')")
			id = cr.fetchone()[0]
			cr.execute('insert into ir_values_keys (id,key,value,parent_id) values (%d,%s,%s,%d)', (id,key,val,parent))
			parent = int(id)
		else:
			parent = int(res[0])

	cr.execute("select nextval('ir_values_id_seq')")
	id = cr.fetchone()[0]
	if not isobject:
		value=pickle.dumps(value)
	cr.execute('insert into ir_values (id,key_id,name,value, object) values (%d,%d,%s,%s,%s)', (int(id), parent, name, value,(isobject and 'True') or 'False'))

	if meta != None:
		cr.execute('update ir_values set meta=%s where id=%d', (pickle.dumps(meta), int(id)))
	if replace:
		cr.execute('delete from ir_values where key_id=%d and id<>%d', (parent,id))

	return True

def ir_del(cr, uid, id):
	cr.execute('delete from ir_values where id=%d', (id,))
	return True

def ir_get(cr, uid, keys, args=[], meta=False, context={}):
	parent = []

	for (key,value) in keys:
		if parent:
			where = ' and parent_id in (%s)' % ','.join(parent)
		else:
			where = ' and parent_id is null'
		if value:
			cr.execute('select id from ir_values_keys where key=%s and value=%s'+where, (key,value))
		else:
			cr.execute('select id from ir_values_keys where key=%s'+where, (key,))
		res = cr.fetchall()
		if not res:
			return []
		parent = map(lambda x: str(x[0]), res)

	for (key,value) in args:
		cr.execute('select id,parent_id from ir_values_keys where key=%s and value=%s and parent_id in ('+','.join(parent)+')', (key,value))
		for res in cr.fetchall():
			parent.remove(str(res[1]))
			parent.insert(0, str(res[0]))

	cr.execute('select id,name,value,object,meta from ir_values where key_id in ('+','.join(parent)+')')
	result = cr.fetchall()

	# x[0] = id // x[1] = name // x[2] = value // x[3] = object // x[4] = meta
	def _result_get(x):
		service = netsvc.LocalService("object_proxy")
		if x[3]:
			model,id = x[2].split(',')
			datas = service.execute(uid, str(model), 'read', [int(id)], False, context)
			if not len(datas):
				ir_del(cr, uid, x[0])
				#assert len(datas), 'IR Ressource does not exist !'
				return False
			datas = datas[0]
		else:
			datas = pickle.loads(x[2])
		if meta:
			return (x[0],x[1],datas,pickle.loads(x[4]))
		return (x[0],x[1],datas)
	return filter(bool, map(lambda x: _result_get(x), list(result)))
