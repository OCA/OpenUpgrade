##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

#
# OSV: Objects Services
#

import orm
import netsvc
import psycopg
import sql_db

class except_osv(Exception):
	def __init__(self, name, value, exc_type='warning'):
		self.name = name
		self.exc_type = exc_type
		self.value = value
		self.args = (exc_type,name)

class osv_pool(netsvc.Service):
	obj_pool = {}
	def __init__(self):
		netsvc.Service.__init__(self, 'object_proxy', audience='')
		self.joinGroup('web-services')
		self.exportMethod(self.exportedMethods)
		self.exportMethod(self.obj_list)
		self.exportMethod(self.exec_workflow)
		self.exportMethod(self.execute)
		self.exportMethod(self.execute_cr)

	def execute_cr(self, cr, uid, obj, method, *args, **kw):
		#
		# TODO: check security level
		#
		try:
			if (not method in getattr(self.obj_pool[obj],'_protected')) and len(args) and args[0] and len(self.obj_pool[obj]._inherits):
				types = {obj: args[0]}
				cr.execute('select inst_type,inst_id,obj_id from inherit where obj_type=%s and  obj_id in ('+','.join(map(str,args[0]))+')', (obj,))
				for ty,id,id2 in cr.fetchall():
					if not ty in types:
						types[ty]=[]
					types[ty].append(id)
					types[obj].remove(id2)
				for t,ids in types.items():
					if len(ids):
						t = self.obj_pool[t]
						res = getattr(t,method)(cr, uid, ids, *args[1:], **kw)
			else:
				obj = self.obj_pool[obj]
#				print 'obj', obj
				res = getattr(obj,method)(cr, uid, *args, **kw)
			return res
		except orm.except_orm, inst:
			self.abortResponse(1, inst.value[0], inst.name, inst.value[1])
		except except_osv, inst:
			self.abortResponse(1, inst.name, inst.exc_type, inst.value)

	def execute(self, uid, obj, method, *args, **kw):
#		print 'executing', method,args
		cr=sql_db.db.cursor()
		res = self.execute_cr(cr, uid, obj, method, *args, **kw)
		cr.commit()
		cr.close()
		return res
#		except psycopg.IntegrityError:
#			raise 'SQL Fault'

	def exec_workflow_cr(self, cr, uid, obj, method, *args):
#		try:
			wf_service = netsvc.LocalService("workflow")
			wf_service.trg_validate(uid, obj, args[0], method, cr)
			return True
#		except orm.except_orm, inst:
#			print 'abort'
#			self.abortResponse(1, inst.value[0], 'ValidateError', inst.value[1])

	def exec_workflow(self, uid, obj, method, *args):
#		try:
			cr=sql_db.db.cursor()
			res = self.exec_workflow_cr(cr, uid, obj, method, *args)
			cr.commit()
			cr.close()
			return res
#		except Exception, e:
#			print e.args
#			print e[0]
#			print dir(e)
#			print type(e)
#		except netsvc.ServiceFailure, inst:
#			self.abortResponse(inst.error, inst.description, inst.origin, inst.details)

	def obj_list(self):
		return self.obj_pool.keys()

	def add(self, name, obj_inst):
		self.obj_pool[name] = obj_inst

	def get(self, name):
		return self.obj_pool[name]

osv_pools = osv_pool()

class osv(orm.orm):
	def __init__(self):
		osv_pools.add(self._name, self)
		self.pool = osv_pools
		orm.orm.__init__(self)

