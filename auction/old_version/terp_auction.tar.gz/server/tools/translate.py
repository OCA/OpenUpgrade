##############################################################################
#
# Copyright (c) 2004 TINY SPRL. (http://tiny.be) All Rights Reserved.
#                    Fabien Pinckaers <fp@tiny.Be>
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsability of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# garantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################

import csv,xml.dom
import osv,tools,sql_db
import convert
import ir

_cache_source = {}
_cache = {}


#
# TODO: a caching method
#
def translate(cr, uid, name, tt, lang, source=None, res_ids=None):
	if source:
		cr.execute('select value from ir_translation where lang=%s and type=%s and name=%s and src=%s', (lang, tt, str(name), source))
	else:
		cr.execute('select value from ir_translation where lang=%s and type=%s and name=%s', (lang, tt, str(name)))
	res_trans = cr.fetchone()
	if res_trans:
		return res_trans[0]
	return False

def trans_parse(out,name,de,lang,cr,uid):
	pool=osv.osv.osv_pools
	for n in [i for i in de.childNodes if (i.nodeType == i.ELEMENT_NODE)]:
		if n.hasAttribute("t"):
			for m in [j for j in n.childNodes if (j.nodeType == j.TEXT_NODE)]:
				l = m.data.strip().replace('\n',' ')
				if len(l):
					res = pool.get('ir.translation')._get_source(cr,uid,name,'xsl',lang,l.encode('utf8')) or ''
					out.append(["xsl",name,"0",l.encode("utf8"),res])
		trans_parse(out,name,n,lang,cr,uid)

def trans_parse2(out,name,de,lang,cr,uid):
	pool=osv.osv.osv_pools
	if de.hasAttribute("string"):
		res= de.getAttribute('string')
		if res:
			res2 = pool.get('ir.translation')._get_source(cr,uid,name,'view',lang,res.encode('utf8')) or ''
			out.append(["view",name,"0",res.encode("utf8"),res2])
	for n in [i for i in de.childNodes if (i.nodeType == i.ELEMENT_NODE)]:
		trans_parse2(out,name,n,lang,cr,uid)

def trans_load(filename, lang, strict=False):
	cr=sql_db.db.cursor()
	cr.execute('delete from ir_translation where lang=%s', (lang,))

	pool=osv.osv.osv_pools
	ids = pool.get('res.lang').search(cr, 1, [('code','=',lang)])
	if not ids:
		ids = pool.get('res.lang').create(cr, 1, {'code':lang,'name':lang})
	lang_ids = pool.get('res.lang').search(cr, 1, [])
	langs = pool.get('res.lang').read(cr, 1, lang_ids)
	ls = map(lambda x: (x['code'],x['name']),langs)
	ir.ir_set(cr, 1, [('meta','res.users'),('name','lang')], [], 'lang', False, True, meta = {'type':'selection', 'string':'Language', 'selection':[(False,'en')]+ls})

	input = file(filename,'r').read().split('\n')
	pool=osv.osv.osv_pools
	uid=1
	reader = csv.reader(input)
	for row in reader:
		f=row
		break
	for row in reader:
		if (not row) or (not row[4]):
			continue
		dic={'lang':lang}
		for i in range(len(f)):
			if pool.get('ir.translation')._columns[f[i]]._type=='integer':
				row[i] = (row[i] and int(row[i])) or False
			dic[f[i]]=row[i]
		if dic['type']=='model' and not strict:
			(model,field) = dic['name'].split(',')
			ids = pool.get(model).search(cr,uid,[(field,'=',dic['src'])])
			for id in ids or [dic['res_id']]:
				dic['res_id'] = id
				try:
					pool.get('ir.translation').create(cr,uid,dic)
				except Exception, e:
					print "ImportError ", e ,' in ',row
		else:
			try:
				pool.get('ir.translation').create(cr,uid,dic)
			except Exception, e:
				print "ImportError ", e ,' in ',row
	cr.commit()
	cr.close()

def trans_generate(filename, lang):
	pool=osv.osv.osv_pools
	cr=sql_db.db.cursor()
	uid=1
	l=pool.obj_pool.items()
	l.sort()
	fname="Translation"
	if lang:
		fname=lang+" "+fname
	out=[["type","name","res_id","src","value"]]
	for (context,obj) in l:
		for (k,v) in obj._columns.items():
			name=context+","+k
			value=""
			if lang:
				cr.execute("SELECT * FROM ir_translation WHERE type='field' AND name=%s AND lang=%s",(name,lang))
				res=cr.dictfetchall()
				if len(res):
					value=res[0]['value']
			out.append(["field",name,"0",v.string,value])
			if v.translate:
				for i in obj.read(cr,uid,obj.search(cr,uid,[]),[k]):
					value=""
					if lang:
						cr.execute("SELECT * FROM ir_translation WHERE type='model' AND name=%s AND res_id=%d AND lang=%s",(name,i['id'],lang))
						res=cr.dictfetchall()
						if len(res):
							value=res[0]['value']
					out.append(["model",name,i['id'],i[k],value])
	obj=pool.get("ir.actions.report.xml")
	for i in obj.read(cr,uid,obj.search(cr,uid,[])):
		name=i["report_name"]
		if i["report_xsl"]:
			try:
				xmlstr=tools.file_open(i["report_xsl"]).read()
				d = xml.dom.minidom.parseString(xmlstr)
				de = d.documentElement
				trans_parse(out,name,de,lang,cr,uid)
			except IOError:
				pass
	obj=pool.get("ir.ui.view")
	for i in obj.read(cr,uid,obj.search(cr,uid,[])):
		d = xml.dom.minidom.parseString(i['arch'])
		de = d.documentElement
		trans_parse2(out,i['model'],de,lang,cr,uid)
	writer = csv.writer(file(filename, "w"))
	for row in out:
		writer.writerow(row)
	cr.close()

