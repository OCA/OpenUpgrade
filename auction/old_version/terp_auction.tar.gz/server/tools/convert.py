#----------------------------------------------------------
# Convert 
#----------------------------------------------------------
import re
import StringIO,xml.dom.minidom
import osv,ir,sql_db

import csv

from config import config

class ConvertError(Exception):
	def __init__(self, doc, orig_excpt):
		self.d = doc
		self.orig = orig_excpt
	
	def __str__(self):
		return 'Exception:\n\t%s\nUsing file:\n%s' % (self.orig, self.d)

# csv
def convert_csv_import(model,input, default={}):
	input=StringIO.StringIO(input)
	pool=osv.osv.osv_pools
	cr=sql_db.db.cursor()
	uid=1
	reader = csv.reader(input)
	for row in reader:
		f=row
		break
	for row in reader:
		dic={}
		dic.update(default)
		for i in range(len(f)):
			if pool.get(model)._columns[f[i]]._type=='integer':
				row[i] = (row[i] and int(row[i])) or False
			elif pool.get(model)._columns[f[i]]._type=='float':
				row[i] = (row[i] and float(row[i])) or False
			elif pool.get(model)._columns[f[i]]._type=='many2one':
				res = pool.get(obj).name_search(cr, uid, row[i], [], '=')
				dic[f[i]] = False
				if len(res):
					dic[f[i]] = res[0][0]
			dic[f[i]]=row[i]
		pool.get(model).create(cr,uid,dic)
	cr.commit()
	cr.close()

def convert_csv_export(csv):
	pass

def _eval_xml(node, pool, cr, uid, idref):
	if node.nodeType == node.ELEMENT_NODE and (node.nodeName in ('field','value')):
		t = node.getAttribute('type') or 'char'
		if len(node.getAttribute('search')):
			f_search=node.getAttribute("search").encode('ascii')
			f_model=node.getAttribute("model").encode('ascii')
			f_use=node.getAttribute("use").encode('ascii')
			if len(f_use)==0:
				f_use="id"
			q=eval(f_search,idref)
			s=pool.get(f_model).read(cr,uid,pool.get(f_model).search(cr,uid,q))
			f_val = False
			if len(s):
				f_val=s[0][f_use]
				if isinstance(f_val,tuple):
					f_val=f_val[0]
			return f_val
		a_eval=node.getAttribute('eval')
		if len(a_eval):
			return eval(a_eval,idref)
		if t == 'xml':
			txt = '<?xml version="1.0"?>\n'+"".join([i.toxml().encode("utf8") for i in node.childNodes])
			return txt % idref
		if t in ('char','int','float'):
			d=""
			for n in [i for i in node.childNodes]:
				d+=str(_eval_xml(n,pool,cr,uid,idref))
			if t=='int':
				d=d.strip()
				if d=='None':
					return None
				else:
					d=int(d.strip())
			elif t=='float':
				d=float(d.strip())
			return d
		elif t in ('list','tuple'):
			res=[]
			for n in [i for i in node.childNodes if (i.nodeType == i.ELEMENT_NODE and i.nodeName=='value')]:
				res.append(_eval_xml(n,pool,cr,uid,idref))
			if t=='tuple':
				return tuple(res)
			return res
	elif node.nodeType == node.ELEMENT_NODE and node.nodeName=="getitem":
			for n in [i for i in node.childNodes if (i.nodeType == i.ELEMENT_NODE)]:
				res=_eval_xml(n,pool,cr,uid,idref)
			if node.getAttribute('type') in ("int","list"):
				return res[int(node.getAttribute('index'))]
			else:
				return res[node.getAttribute('index').encode("utf8")]
	elif node.nodeType == node.ELEMENT_NODE and node.nodeName=="function":
		args=[]
		a_eval=node.getAttribute('eval')
		if len(a_eval):
			args = eval(a_eval,idref)
		for n in [i for i in node.childNodes if (i.nodeType == i.ELEMENT_NODE)]:
			args.append(_eval_xml(n, pool, cr, uid,idref))
		model=pool.get(node.getAttribute('model'))
		method=node.getAttribute('name')
		res = getattr(model,method)(cr,uid,*args)
		return res
	elif node.nodeType == node.TEXT_NODE:
		return node.data.encode("utf8")

escape_re = re.compile(r'(?<!\\)/')
def escape(x):
	return x.replace('\\/', '/')

# xml import/export
def convert_xml_import(xmlstr, idref={}):
	uid = 1
	pool = osv.osv.osv_pools
	cr = sql_db.db.cursor()
	try:
		d = xml.dom.minidom.parseString(xmlstr)
	except Exception, e:
		raise ConvertError(xmlstr, e)
	de = d.documentElement
	# Foreach data
	for n in [i for i in de.childNodes if (i.nodeType == i.ELEMENT_NODE and i.nodeName=="data")]:
			update = n.getAttribute("update").encode('ascii')
			if len(update):
				if not (config['update'].has_key(update) or config['update'].has_key("all")):
					continue
			# Foreach rec
			for rec in n.childNodes:
				# TODO: more general ir_get ir_set
				if rec.nodeType == rec.ELEMENT_NODE:
					if rec.nodeName=="menuitem":
						a_name = rec.getAttribute("name").encode('utf8')

						ir_ui_menu = pool.get('ir.ui.menu')
						m_l = [escape(x) for x in escape_re.split(a_name)]
						pid = 1
						for i in m_l:
							m_s = ir_ui_menu.search(cr,uid,[('parent_id','=',pid),('name','=',i)])
							if len(m_s):
								m_id = m_s[0]
							else:
								m_id = ir_ui_menu.create(cr,uid,{'parent_id': pid,'name':i})
							pid=m_id

						# ir_set menu
						if rec.hasAttribute('action'):
							a_action = rec.getAttribute('action').encode('utf8')
							a_id = idref[a_action]
							a_type = rec.getAttribute('type').encode('utf8') or 'act_window'
							action = "ir.actions.%s,%d" % (a_type, a_id)
							ir.ir_set(cr, uid, [('action','tree_but_open'),('res_model','ir.ui.menu'),('res_id',m_id)], [], 'Menuitem', action, True, True)

					elif rec.nodeName=="report":
						# record
						string = rec.getAttribute("string").encode('utf8')
						model = rec.getAttribute("model").encode('utf8')
						name = rec.getAttribute("name").encode('utf8')
#TODO: check these 3 fields are not equal to '' !						
						res = {'model': model, 'name': string, 'report_name': name}
						if rec.hasAttribute('xml'):
							res.update({'report_xml': rec.getAttribute('xml').encode('utf8')})
						if rec.hasAttribute('xsl'):
							res.update({'report_xsl': rec.getAttribute('xsl').encode('utf8')})
						if rec.hasAttribute('auto'):
							res.update({'auto': eval(rec.getAttribute('auto'))})
						id = pool.get("ir.actions.report.xml").create(cr, uid, res)

						# save id
						rec_id = rec.getAttribute("id").encode('ascii')
						if len(rec_id):
							idref[rec_id] = id

						# ir_set
						if not rec.hasAttribute('menu') or eval(rec.getAttribute('menu')):
							if rec.hasAttribute('trigger_model'):
								trigger_model = rec.getAttribute("trigger_model").encode('utf8')
							else:
								trigger_model = model
							keys = [('action','client_print_multi'),('res_model',trigger_model)]
							value = 'ir.actions.report.xml,'+str(id)
							replace = rec.hasAttribute('replace') and rec.getAttribute("replace")
							ir.ir_set(cr, uid, keys, [], string, value, replace=replace, isobject=True, meta=None)

					elif rec.nodeName=="wizard":
						# record
						string = rec.getAttribute("string").encode('utf8')
						model = rec.getAttribute("model").encode('utf8')
						name = rec.getAttribute("name").encode('utf8')
						res = {'name': string, 'wiz_name': name}
						id = pool.get("ir.actions.wizard").create(cr, uid, res)

						# save id
						rec_id = rec.getAttribute("id").encode('ascii')
						if len(rec_id):
							idref[rec_id] = id

						# ir_set
						keyword = str(rec.getAttribute('keyword') or 'client_action_multi')
						keys = [('action',keyword),('res_model',model)]
						value = 'ir.actions.wizard,'+str(id)
						replace = rec.hasAttribute('replace') and rec.getAttribute("replace")
						ir.ir_set(cr, uid, keys, [], string, value, replace=replace, isobject=True, meta=None)

					elif rec.nodeName=="delete":
						d_model = rec.getAttribute("model")
						d_search = rec.getAttribute("search")
						model = pool.get(d_model)
						ids = model.search(cr,uid,eval(d_search))
						if len(ids):
							model.unlink(cr,uid,ids)

					elif rec.nodeName=="ir_set":
						res = {}
						for field in  [i for i in rec.childNodes if (i.nodeType == i.ELEMENT_NODE and i.nodeName=="field")]:
							f_name = field.getAttribute("name").encode('ascii')
							f_val = _eval_xml(field, pool, cr, uid, idref)
							res[f_name] = f_val
						ir.ir_set(cr, uid, res['keys'], res.get('args', {}), res['name'], res['value'], replace=res.get('replace',True), isobject=res.get('isobject', False), meta=res.get('meta',None))

					elif rec.nodeName=="workflow":
						import netsvc
						wf_service = netsvc.LocalService("workflow")
						wf_service.trg_validate(uid, str(rec.getAttribute('model')), idref[rec.getAttribute('ref')], str(rec.getAttribute('action')), cr)

					elif rec.nodeName=="record":
						rec_model = rec.getAttribute("model").encode('ascii')
						rec_id = rec.getAttribute("id").encode('ascii')
						model = pool.get(rec_model)
						res = {}
						# Foreach field
						for field in [i for i in rec.childNodes if (i.nodeType == i.ELEMENT_NODE and i.nodeName=="group")]:
							for (k,v) in field.attributes.items():
								res[k.encode("utf8")] = v.encode("utf8")
						for field in [i for i in rec.childNodes if (i.nodeType == i.ELEMENT_NODE and i.nodeName=="field")]:
							f_name = field.getAttribute("name").encode('ascii')
							f_ref = field.getAttribute("ref").encode('ascii')
							f_search = field.getAttribute("search").encode('ascii')
							f_model = field.getAttribute("model").encode('ascii')
							f_use = field.getAttribute("use").encode('ascii')
							f_val = False
							if len(f_search):
								if len(f_use)==0:
									f_use = "id"
								if len(f_model)==0:
									f_model = model._columns[f_name]._obj
								q = eval(f_search,idref)
								s = pool.get(f_model).read(cr,uid,pool.get(model._columns[f_name]._obj).search(cr,uid,q))
								if len(s):
									f_val = s[0][f_use]
									if isinstance(f_val,tuple):
										f_val = f_val[0]
							elif len(f_ref):
								if f_ref=="null":
									f_val = False
								elif idref.has_key(f_ref):
									f_val = idref[f_ref]
								else:
									f_val = int(f_ref)
							else:
								f_val = _eval_xml(field, pool, cr, uid, idref)
								if model._columns.has_key(f_name):
									if isinstance(model._columns[f_name],osv.fields.integer):
										f_val = int(f_val)
							res[f_name] = f_val
						id = model.create(cr,uid,res)
						if len(rec_id):
							idref[rec_id] = id
							
					elif rec.nodeName=="function":
						_eval_xml(rec, pool, cr, uid, idref)
	cr.commit()
	cr.close()
	return True

def convert_xml_export(res):
	uid=1
	pool=osv.osv.osv_pools
	cr=sql_db.db.cursor()
	idref = {}
	d = xml.dom.minidom.getDOMImplementation().createDocument(None, "terp", None)
	de = d.documentElement
	data=d.createElement("data")
	de.appendChild(data)
	de.appendChild(d.createTextNode('Some textual content.'))
	cr.commit()
	cr.close()
