{
	"name" : "Thunderbird Interface",
	"version" : "1.0",
	"author" : "Axelor",
	"website" : "http://www.axelor.com/",
	"depends" : ["base","crm"],
	"category" : "Generic Modules/Thunderbird interface",
	"init_xml" : [],
	"demo_xml" : [],
	"update_xml" : ["partner/partner_view.xml"],
	"active": True,
	"installable": True
}
